module Dock
  module Warehouse
    class ExtractJob < JobBase


      def perform
      end

      private
      def prepare
      end

    end
  end
end
