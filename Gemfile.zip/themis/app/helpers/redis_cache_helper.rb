module RedisCacheHelper
  def drop_dropdown_items_cache
		Rails.cache.delete_matched("dropdown_*")
	end
end
