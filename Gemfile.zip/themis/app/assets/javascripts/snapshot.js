// var page = require('webpage').create();
// page.open('https://mantis.appleflying.com/login/index', function () {
//     page.render('/Users/evanchiu/Downloads/example.png');
//     phantom.exit();
// });
