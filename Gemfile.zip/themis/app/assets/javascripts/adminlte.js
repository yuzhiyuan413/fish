//= require app.min
//= require demo
//= require fastclick.min
//= require jquery.slimscroll.min
//= require bootstrap-table
