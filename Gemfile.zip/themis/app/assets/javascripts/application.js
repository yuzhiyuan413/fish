// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or any plugin's vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery-1.12.0.min
//= require jquery_ujs
//= require turbolinks
//= require bootstrap-sprockets

//= require jquery.dataTables.min
//= require dataTables.fixedColumns.min
//= require dataTables.buttons.min
//= require buttons.flash.min
//= require jszip.min
//= require pdfmake.min
//= require vfs_fonts
//= require buttons.html5.min
//= require buttons.print.min


//= require jquery.ui.datepicker
//= require jquery.ui.datepicker-zh-CN
//= require bootstrap
//= require bootstrap/tab
//= require bootstrap/collapse
//= require bootstrap/dropdown
//= require bootstrap-switch
//= require select2
//= require bootstrap-datetimepicker
//= require locales/bootstrap-datetimepicker.zh-CN
//= require jquery_pin
//= require spin
//= require ladda
//= require bootstrap-combobox

// Init JS Component
$(document).on("page:change",function() {
    $(".select2").select2();
    $(".bootstrap_switch").bootstrapSwitch();
    $.datepicker.setDefaults($.datepicker.regional['zh-CN']);
    $(".datetimepicker").datepicker({dateFormat:"yy-mm-dd"});
    $(".mounthpicker").datetimepicker({
        language: 'zh-CN',
        format: 'yyyy/mm',
        startView: 3,
        minView: 3,
        maxView: 3
    });
    $('.DTFC_LeftWrapper').remove();
    Ladda.bind('button[type=submit]');
    $(".pinned").pin();
    $(".autocomplete").combobox();
    $(".accordion").collapse();
    $('.dropdown-toggle').dropdown();

    $(".download_btn").click(function(){
      $(this).next().children().first().toggle();
    })

    $(document).click(function (event) {
        if($(event.target).parent()[0].className=="dt-buttons"){
            return false;
        }

       $(".dt-buttons").hide();

    })
});


function init_dataTables(id,has_buttons,sort_ele){
	var buttons = []
	if (has_buttons){
		buttons = ['copy', 'csv', 'excel', 'pdf', 'print']
	}

	$('#'+id).DataTable({
	"language":
	{
     "zeroRecords": "没有找到记录",
     "search" : "全文搜索",
     "processing":   "处理中...",
     "info": "显示  _TOTAL_ 条记录",
     "infoEmpty": "无记录",
     "infoFiltered": "(从 _MAX_ 条记录过滤)"
    },
    dom: 'Bfrti',
    buttons: buttons,
    columnDefs:sort_ele,
    scrollY:        "500px",
    scrollX:        true,
    scrollCollapse: true,
    paging:         false,
    fixedColumns:   true
  });
}

