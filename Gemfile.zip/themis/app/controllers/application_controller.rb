class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  include Pass::ControllerHelper
  around_action :permission_filter

  protected
    def current_account
      @current_account ||= System::Account.find current_account_id
    end

    def current_account= account
      logger.info "新用户登录:#{account.inspect}"
      session[:account_id_login] = account.id
      session[:current_account] = account
    end
end
