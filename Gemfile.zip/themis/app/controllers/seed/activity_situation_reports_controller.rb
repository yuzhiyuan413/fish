# -*- encoding : utf-8 -*-
class Seed::ActivitySituationReportsController < ApplicationController
  # GET /seed/activity_situation_reports
  # GET /seed/activity_situation_reports.json
  def index
    params.permit!
    @activity_situation_report = Seed::ActivitySituationReport.new(params[:seed_activity_situation_report])
    @activity_situation_report.report_type = "1"
    @activity_situation_report.tag ||= System::TagGroup::TOTAL_SUM_TAG

    @situation_reports = @activity_situation_report.situation_reports
    @total_report = @activity_situation_report.total_report
    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @activity_situation_report }
    end
  end

end
