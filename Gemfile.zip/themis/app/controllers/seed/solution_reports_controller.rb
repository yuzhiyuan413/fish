# -*- encoding : utf-8 -*-
class Seed::SolutionReportsController < ApplicationController
  # GET /seed/solution_reports
  # GET /seed/solution_reports.json
  def index
    params.permit!
    @seed_solution_report = Seed::SolutionReport.new(params[:seed_solution_report])
    @seed_solution_report.from_date ||= Date.today.ago(7.days).to_date.to_s
    @seed_solution_report.end_date ||= Date.today.to_s
    @seed_solution_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_solution_reports = @seed_solution_report.search
    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_solution_reports }
    end
  end

end
