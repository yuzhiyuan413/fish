# -*- encoding : utf-8 -*-
class Seed::AliveReportsController < ApplicationController
  # GET /seed/alive_reports
  # GET /seed/alive_reports.json
  def index
    params.permit!
    @seed_alive_report = Seed::AliveReport.new(params[:seed_alive_report])
    @seed_alive_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_alive_report.from_date ||= Date.today.ago(7.days).to_date.to_s
    @seed_alive_report.end_date ||= Date.yesterday.to_s
    @seed_alive_reports = @seed_alive_report.search
    @alive_report_avg =@seed_alive_report.stay_alive_avg @seed_alive_reports
    @stay_alive_median = Median.find_by_name(Seed::AliveReport.to_s)

    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_alive_reports }
    end
  end

end
