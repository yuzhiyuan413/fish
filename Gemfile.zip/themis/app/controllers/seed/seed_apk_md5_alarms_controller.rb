# -*- encoding : utf-8 -*-
class Seed::SeedApkMd5AlarmsController < ApplicationController
  # GET /seed/apk_md5_alarms
  # GET /seed/apk_md5_alarms.json
  def index
    params.permit!
    @seed_seed_apk_md5_alarm = Seed::SeedApkMd5Alarm.new(params[:seed_seed_apk_md5_alarm])
    @seed_seed_apk_md5_alarm.from_date ||= Date.today.ago(30.days).to_date.to_s
    @seed_seed_apk_md5_alarm.end_date ||= Date.today.to_s
    @seed_seed_apk_md5_alarm.tag ||= Api::SeedTag.first.tag
    @seed_seed_apk_md5_alarms = @seed_seed_apk_md5_alarm.search
    @seed_apk_md5_alarms_sum_record = @seed_seed_apk_md5_alarm.sum_record @seed_seed_apk_md5_alarms
    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_seed_apk_md5_alarms }
    end
  end

end
