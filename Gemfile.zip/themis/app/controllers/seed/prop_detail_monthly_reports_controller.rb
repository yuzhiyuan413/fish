# -*- encoding : utf-8 -*-
class Seed::PropDetailMonthlyReportsController < ApplicationController
  # GET /seed/prop_detail_monthly_reports
  # GET /seed/prop_detail_monthly_reports.json
  def index
    params.permit!
    @seed_prop_detail_monthly_report = Seed::PropDetailMonthlyReport.new(params[:seed_prop_detail_monthly_report])
    @seed_prop_detail_monthly_report.report_date ||= Date.yesterday.strftime("%Y/%m")
    @seed_prop_detail_monthly_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_prop_detail_monthly_report.manufacturer ||= "全部厂商"
    @seed_prop_detail_monthly_report.board ||= "全部型号"
    @seed_prop_detail_monthly_reports = @seed_prop_detail_monthly_report.search

    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_prop_detail_monthly_reports }
    end
  end

end
