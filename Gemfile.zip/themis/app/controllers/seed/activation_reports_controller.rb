# -*- encoding : utf-8 -*-
class Seed::ActivationReportsController < ApplicationController
  # GET /seed/seed_activation_reports
  # GET /seed/seed_activation_reports.json
  def index
    params.permit!
    @seed_activation_report = Seed::ActivationReport.new(params[:seed_activation_report])
    @seed_activation_report.from_date ||= Date.today.ago(7.days).to_date.to_s
    @seed_activation_report.end_date ||= Date.today.to_s
    @seed_activation_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_activation_reports = @seed_activation_report.search
    @seed_activation_sum_record = @seed_activation_report.sum_record @seed_activation_reports
    respond_to do |format|
      format.html #index.html.erb
      format.json { render :json => @seed_activation_reports }
    end
  end

end
