# -*- encoding : utf-8 -*-
class Seed::DeviceDetailReportsController < ApplicationController
  # GET /seed/device_detail_reports
  # GET /seed/device_detail_reports.json
  def index
    params.permit!
    @seed_device_detail_report = Seed::DeviceDetailReport.new(params[:seed_device_detail_report])
    @seed_device_detail_report.from_date ||= Date.today.to_s
    @seed_device_detail_report.end_date ||= Date.today.to_s
    @seed_device_detail_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_device_detail_reports = @seed_device_detail_report.search
    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_device_detail_reports } 
    end
  end

end
