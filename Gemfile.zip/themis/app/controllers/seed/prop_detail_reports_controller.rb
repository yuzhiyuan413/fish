# -*- encoding : utf-8 -*-
class Seed::PropDetailReportsController < ApplicationController
  # GET /seed/prop_detail_reports
  # GET /seed/prop_detail_reports.json
  def index
    params.permit!
    @seed_prop_detail_report = Seed::PropDetailReport.new(params[:seed_prop_detail_report])
    @seed_prop_detail_report.from_date ||= Date.today.to_s
    @seed_prop_detail_report.end_date ||= Date.today.to_s
    @seed_prop_detail_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_prop_detail_reports = @seed_prop_detail_report.search
    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_prop_detail_reports }
    end
  end

end
