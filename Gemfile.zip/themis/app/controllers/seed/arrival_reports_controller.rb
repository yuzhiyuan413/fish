# -*- encoding : utf-8 -*-
class Seed::ArrivalReportsController < ApplicationController
  # GET /seed/arrival_reports
  # GET /seed/arrival_reports.json
  def index
    params.permit!
    @seed_arrival_report = Seed::ArrivalReport.new(params[:seed_arrival_report])
    @seed_arrival_report.from_date ||= 7.days.ago.strftime("%F")
    @seed_arrival_report.end_date ||= Date.today.to_s
    @seed_arrival_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_arrival_reports = @seed_arrival_report.search
    @seed_arrival_report_summray = @seed_arrival_report.sum_record @seed_arrival_reports

    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_arrival_reports }
    end
  end

end
