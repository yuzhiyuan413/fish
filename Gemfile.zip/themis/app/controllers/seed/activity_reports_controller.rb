# -*- encoding : utf-8 -*-
class Seed::ActivityReportsController < ApplicationController
  # GET /seed/activity_reports
  # GET /seed/activity_reports.json
  def index
    params.permit!
    @seed_activity_report = Seed::ActivityReport.new(params[:seed_activity_report])
    @seed_activity_report.from_date ||= Date.today.ago(7.days).to_date.to_s
    @seed_activity_report.end_date ||= Date.today.to_s
    @seed_activity_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_activity_reports = @seed_activity_report.search
    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_activity_report }
    end
  end
end
