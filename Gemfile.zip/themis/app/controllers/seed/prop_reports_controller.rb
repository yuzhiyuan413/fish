# -*- encoding : utf-8 -*-
class Seed::PropReportsController < ApplicationController
  # GET /seed/prop_reports
  # GET /seed/prop_reports.json
  def index
    params.permit!
    @seed_prop_report = Seed::PropReport.new(params[:seed_prop_report])
    @seed_prop_report.from_date ||= Date.today.to_s
    @seed_prop_report.end_date ||= Date.today.to_s
    @seed_prop_report.tag ||= System::TagGroup::TOTAL_SUM_TAG
    @seed_prop_reports = @seed_prop_report.search
    respond_to do |format|
      format.html # index.html.erb
      format.json { render :json => @seed_prop_reports }
    end
  end

end
