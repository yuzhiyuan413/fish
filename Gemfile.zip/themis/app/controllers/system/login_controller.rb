# encoding: utf-8
class System::LoginController < ApplicationController
  before_action :check_login_params, only: [:do_login]

  def index
    render layout: "login"
  end

  def do_login
    @account = System::Account.check_account(params[:name], params[:password])
    if @account.is_a?(String)
      flash[:warning] = @account
      render action: :index, layout: "login"
    else
      reset_session
      self.current_account = @account
      root_func = self.current_account.available_functions.first
      if root_func
        redirect_to controller: root_func.controller, action: root_func.action
      else
        permission_error
      end
    end
  end

  def timeout
    render layout: "login"
  end

  def logout
    reset_session
    render action: :index, layout: "login"
  end

  def permission_error
    flash[:warning] = "没有权限, 请联系管理员."
    render action: :index, layout: "login"
  end

  private
    def secure?
      false
    end

    def check_login_params
      if params[:name].blank? or params[:password].blank?
        flash[:warning] = "用户名，密码不能为空!"
        render action: :index, layout: "login"
      end
    end

end
