# -*- encoding : utf-8 -*-
class Ds::SwordPropRepository < Ds::Repository

  def prop_records_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_records_by_tag_group(tag, begin_time, end_time)
  end

  def prop_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_records(begin_time, end_time)
  end

  def prop_detail_records_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_detail_records_by_tag_group(tag, begin_time, end_time)
  end

  def prop_detail_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_detail_records(begin_time, end_time)
  end

  def count_prop_sum_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.count_prop_sum_by_tag_group(tag, begin_time, end_time)
  end
  def prop_sum_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_sum_records(begin_time, end_time)
  end


  def prop_succ_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_succ_records(begin_time, end_time)
  end

  def prop_detail_succ_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_detail_succ_records(begin_time, end_time)
  end

  def prop_succ_records_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_succ_records_by_tag_group(tag, begin_time, end_time)
  end

  def prop_detail_succ_records_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_detail_succ_records_by_tag_group(tag, begin_time, end_time)
  end

  def count_prop_succ_sum_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.count_prop_succ_sum_by_tag_group(tag, begin_time, end_time)
  end

  def prop_succ_sum_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::Prop.prop_succ_sum_records(begin_time, end_time)
  end

end
