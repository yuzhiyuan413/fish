# -*- encoding : utf-8 -*-
class Ds::ChargeActivationRepository < Ds::Repository
  def charge_activation_num
    ChargeDs::ChargeUser.count_activation(params[:date], params[:tag], params[:product_version])
  end

  def activation_records begin_time, end_time, group_columns
    ChargeDs::ChargeUser.group_activation_by(begin_time, end_time, group_columns)
  end

  def total_activation_records group_columns
    ChargeDs::ChargeUser.group_total_activation_by(group_columns)
  end

  def activation_situation_records report_date
    Charge::ActivationReport.find_all_by_report_date(report_date)
  end

  def activation_records_v9 begin_time, end_time, group_columns
    ChargeDs::ChargeUser.group_activation_v9(begin_time, end_time, group_columns)
  end

  def activation_situation_records_v9 report_date
    Charge::ActivationReport.find_all_by_product_version_and_report_date("9.0", report_date)
  end

  def count_activation_v9(tag, begin_time, end_time = begin_time.end_of_day)
    ChargeDs::ChargeUser.count_activation_v9(tag, begin_time, end_time)
  end

end
