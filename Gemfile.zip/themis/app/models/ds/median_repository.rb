# -*- encoding : utf-8 -*-
class Ds::MedianRepository < Ds::Repository
	def avg_stay_alive mdl, key, value
		model_class = mdl.constantize
		records = model_class.avg_stay_alive(key, value).map(&:avg_stay_alive)
		records.delete(0)
		records.blank? ? nil : records.median
	end
end
