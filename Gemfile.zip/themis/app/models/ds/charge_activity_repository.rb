# -*- encoding : utf-8 -*-
class Ds::ChargeActivityRepository < Ds::Repository
  def charge_activity_num
    ChargeDs::ChargeRequestHistory.count_activity(params[:date], params[:tag], params[:product_version], params[:province])
  end

  def charge_request_times
    ChargeDs::ChargeRequestHistory.count_request_times(params[:date], params[:tag], params[:product_version], params[:province])
  end

  def charge_cp_num charge_cp
    ChargeDs::ChargeRequestHistory.count_cp(params[:date], params[:tag], params[:product_version], params[:province], charge_cp)
  end

  def activity_records begin_time, end_time, group_columns
    ChargeDs::ChargeRequestHistory.group_activity_by(begin_time, end_time, group_columns)
  end

  def activity_situation_records report_date
    Charge::ActivityReport.find_all_by_province_and_report_date("全部省份",report_date)
  end

  def charge_max_request_time
    ChargeDs::ChargeRequestHistory.maximum(:request_time)
  end

  def activity_records_v9 begin_time, end_time, group_columns
    ChargeDs::ChargeRequestHistory.group_activity_v9(begin_time, end_time, group_columns)
  end

  def activity_situation_records_v9 report_date
    Charge::ActivityReport.find_all_by_product_version_and_report_date("9.0", report_date)
  end

  def count_activity_v9 tag, begin_time, end_time = begin_time.end_of_day
    ChargeDs::ChargeRequestHistory.count_activity_v9(tag, begin_time, end_time)
  end

  def count_request_v9 tag, begin_time, end_time = begin_time.end_of_day
    ChargeDs::ChargeRequestHistory.count_request_v9(tag, begin_time, end_time)
  end

end
