# -*- encoding : utf-8 -*-
class Ds::SwordDeviceRepository < Ds::Repository 
	def device_detail_records_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.device_detail_records_by_tag_group(tag, begin_time, end_time)
  end

  def device_detail_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.device_detail_records(begin_time, end_time)
  end

  def count_device_sum_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.count_device_sum_by_tag_group(tag, begin_time, end_time)
  end

  def device_sum_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.device_sum_records(begin_time, end_time)
  end

  def device_detail_succ_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.device_detail_succ_records(begin_time, end_time)
  end

  def device_detail_succ_records_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.device_detail_succ_records_by_tag_group(tag, begin_time, end_time)
  end


  def count_device_succ_sum_by_tag_group(tag, begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.count_device_succ_sum_by_tag_group(tag, begin_time, end_time)
  end

  def device_succ_sum_records(begin_time, end_time = begin_time.end_of_day)
    SwordDs::SeedFeedbackHistory.device_succ_sum_records(begin_time, end_time)
  end
end