# -*- encoding : utf-8 -*-
class Ds::SeedRepository < Ds::Repository

	def group_old_user_activity_by_tag(begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.group_old_user_activity_by_tag(begin_time, end_time)
	end

	def cross_panda_group_activation_by_tag(begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.cross_panda_group_activation_by_tag(begin_time, end_time)
	end

	def group_sign_by_tag(begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.group_sign_by_tag(begin_time, end_time)
	end

	def group_reset_by_tag(begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.group_reset_by_tag(begin_time, end_time)
	end

	def count_old_user_activity(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.count_old_user_activity(tag, begin_time, end_time)
	end

	def count_activation_cross_panda(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.count_activation_cross_panda(tag, begin_time, end_time)
	end

	def count_signature(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.count_signature(tag, begin_time, end_time)
	end

	def count_reset(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.count_reset_num(tag, begin_time, end_time)
	end

	def count_activation(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::SeedUser.count_activation(tag, begin_time, end_time)
	end

	def count_activation_by_tag abnormal_tag
		BeeDs::SeedUser.total_count_activation(abnormal_tag)
	end

	def activation_records begin_time, end_time
		BeeDs::SeedUser.group_activation_by_tag(begin_time, end_time)
	end

	def total_activation_records
		BeeDs::SeedUser.group_total_activation_by_tag
	end

	def max_activation_time
		BeeDs::SeedUser.maximum(:activation_time)
	end

	def group_charge_user_conversion_by_tag begin_time, end_time = begin_time.end_of_day
		BeeDs::SeedUser.group_charge_user_conversion_by_tag(begin_time, end_time)
	end

	def v9_activation_num tag, begin_time, end_time = begin_time.end_of_day
		BeeDs::SeedUser.v9_activation_num(tag, begin_time, end_time)
	end


	def aid_activation_records begin_time, end_time = begin_time.end_of_day
		SwordDs::SeedAidUser.activation_records(begin_time, end_time)
	end

	def count_aid_activation tag, begin_time, end_time = begin_time.end_of_day
		SwordDs::SeedAidUser.count_activation(tag, begin_time, end_time)
	end

	def cross_solution_event_records event_id, begin_time, end_time, conditions=nil
		SwordDs::SeedAidUser.cross_solution_event_records(event_id, begin_time, end_time, conditions)
	end

	def count_cross_solution_event tag, event_id, begin_time, end_time, conditions=nil
		SwordDs::SeedAidUser.count_cross_solution_event(tag, event_id, begin_time, end_time, conditions)
	end

	def cross_v9_activity_records begin_time, end_time = begin_time.end_of_day
		SwordDs::SeedAidUser.cross_v9_activity_records(begin_time, end_time)
	end

	def count_cross_v9_activity tag, begin_time, end_time = begin_time.end_of_day
		SwordDs::SeedAidUser.count_cross_v9_activity(tag, begin_time, end_time)
	end

end
