# -*- encoding : utf-8 -*-
class Ds::ChargeActivityMonthRepository < Ds::Repository
  def charge_activity_num
    ChargeDs::ChargeRequestHistory.count_activity_month(params[:date], params[:tag], params[:province])
  end

  def charge_request_times
    ChargeDs::ChargeRequestHistory.count_request_times_month(params[:date], params[:tag], params[:province])
  end

  def charge_cp_num charge_cp
    ChargeDs::ChargeRequestHistory.count_cp_month(params[:date], params[:tag], params[:province], charge_cp)
  end
end
