# -*- encoding : utf-8 -*-
class Ds::ApkMd5AlarmsRepository < Ds::Repository
	def find_abnormal_tags
		BeeDs::SeedApkMd5Alarm.find_abnormal_tags
	end

	def tag_created_at abnormal_tag
		@all_seed_tag ||= Api::SeedTag.all
		abnormal_tag = @all_seed_tag.collect{|x| x if x.tag.eql? abnormal_tag }.compact.first
		abnormal_tag.try(:created_at)
	end
end
