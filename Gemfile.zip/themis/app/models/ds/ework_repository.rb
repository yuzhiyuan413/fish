# -*- encoding : utf-8 -*-
class Ds::EworkRepository < Ds::Repository
	def activation_records begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.activation_records(begin_time, end_time)
	end

	def count_activation tag, begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.count_activation(tag, begin_time, end_time)
	end

	def conversion_records begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.conversion_records(begin_time, end_time)
	end

	def count_conversion tag, begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.count_conversion(tag, begin_time, end_time)
	end

	def count_seed_event_cross_ework tag, solution_event_id, begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.count_seed_event_cross_ework(tag, solution_event_id, begin_time, end_time)
	end

	def seed_event_records solution_event_id, begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.seed_event_records(solution_event_id, begin_time, end_time)
	end

	def cross_solution_event_records event_id, begin_time, end_time, conditions=nil
		EworkDs::TPhonearg.cross_solution_event_records(event_id, begin_time, end_time, conditions)
	end

	def count_cross_solution_event tag, event_id, begin_time, end_time, conditions=nil
		EworkDs::TPhonearg.count_cross_solution_event(tag, event_id, begin_time, end_time, conditions)
	end

	def cross_v9_activity_records begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.cross_v9_activity_records(begin_time, end_time)
	end

	def count_cross_v9_activity tag, begin_time, end_time = begin_time.end_of_day
		EworkDs::TPhonearg.count_cross_v9_activity(tag, begin_time, end_time)
	end

end
