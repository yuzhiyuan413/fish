# -*- encoding : utf-8 -*-
class Ds::PandaRepository < Ds::Repository

	def group_old_user_activation_by_tag date
		PandaDs::User.group_old_user_activation_by_tag date
	end

	def group_old_user_lose_by_tag date
		PandaDs::User.group_old_user_lose_by_tag date
	end

	def count_old_user_activation(tag, date)
		PandaDs::User.count_old_user_activation(tag, date)
	end

	def count_old_user_lose(tag, date)
		PandaDs::User.count_old_user_lose(tag, date)
	end

end
