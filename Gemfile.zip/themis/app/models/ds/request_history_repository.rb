# -*- encoding : utf-8 -*-
class Ds::RequestHistoryRepository < Ds::Repository

	def stay_alive_records(activation_date, stay_alive_date)
		BeeDs::RequestHistory.stay_alive_records(activation_date, stay_alive_date)
	end

	def count_stay_alive (tag, activation_date, stay_alive_date)
		BeeDs::RequestHistory.count_stay_alive(tag, activation_date, stay_alive_date)
	end

	def count_activity(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::RequestHistory.count_activity(tag, begin_time, end_time)
	end

	def count_embed(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::RequestHistory.count_embed(tag, begin_time, end_time)
	end

	def count_sign(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::RequestHistory.count_sign(tag, begin_time, end_time)
	end

	def count_request(tag, begin_time, end_time = begin_time.end_of_day)
		BeeDs::RequestHistory.count_request(tag, begin_time, end_time)
	end

	def activity_records(begin_time, end_time)
		BeeDs::RequestHistory.group_activity_by_tag(begin_time, end_time)
	end

	def activity_num_records(begin_time, end_time)
		BeeDs::RequestHistory.group_activity_num_by_tag(begin_time, end_time)
	end

	def embed_records
		BeeDs::RequestHistory.group_embed_by_tag(params[:date])
	end

	def sign_records
		BeeDs::RequestHistory.group_sign_by_tag(params[:date])
	end

	def max_record_time
		BeeDs::RequestHistory.maximum(:record_time)
	end
end
