# -*- encoding : utf-8 -*-
class Ds::Repository

	attr_accessor :repositories, :params

  def getr(rid)
    rs = repositories.select{ |r| r.match? rid }
    if rs.size > 1
      raise "相同的id返回多个Repository. #{rs.collect{|c| c.class.name}.inspect}"
    end
    if rs.empty?
      raise "没有支持的Repository. #{rid}"
    end
    return rs.first
  end

  def match? id
    self.class.name.split("::").last.split("Repository").first.underscore.to_sym == id
  end

end
