# -*- encoding : utf-8 -*-
class Ds::ActivityRepository < Ds::Repository

	def seed_activity_situation_records report_date
		Seed::ActivityReport.find_all_by_report_time(report_date)
	end

	def count_activity_num_by_tags_at_ytm(report_type, tags, end_time)
		BeeDs::RequestHistory.count_activity(tags, Date.yesterday.beginning_of_day, end_time)
	end

	def count_activation_num_by_tags_ytm(report_type, tags, end_time)
		BeeDs::SeedUser.count_activation(tags, Date.yesterday.beginning_of_day, end_time)
	end

	def count_request_times_by_tags_ytm(report_type, tags, end_time)
		BeeDs::RequestHistory.count_request(tags, Date.yesterday.beginning_of_day, end_time)
	end

	def total_activation_num report_type, tag
		BeeDs::SeedUser.total_count_activation tag
  end

end
