# -*- encoding : utf-8 -*-
class Ds::SwordSolutionEventRepository < Ds::Repository

  def event_records_by_tag_group(tag, event_name, begin_time, end_time, condition = nil)
    SwordDs::SeedFeedbackHistory.event_records_by_tag_group(tag, event_name, begin_time, end_time, condition)
  end

  def event_records(event_name, begin_time, end_time, condition = nil)
    SwordDs::SeedFeedbackHistory.event_records(event_name, begin_time, end_time, condition)
  end

  def count_event_sum_by_tag_group(tag, event_name, begin_time, end_time, condition = nil)
    SwordDs::SeedFeedbackHistory.count_event_sum_by_tag_group(tag, event_name, begin_time, end_time, condition)
  end

  def event_sum_records(event_name, begin_time, end_time, condition = nil)
    SwordDs::SeedFeedbackHistory.event_sum_records(event_name, begin_time, end_time, condition)
  end

end
