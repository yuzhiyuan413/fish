# -*- encoding : utf-8 -*-
class Ds::ChargeAliveRepository < Ds::Repository
  def stay_alive_records activation_date, stay_alive_date, group_columns
    ChargeDs::ChargeUser.stay_alive_records(activation_date, stay_alive_date, group_columns)
  end
end
