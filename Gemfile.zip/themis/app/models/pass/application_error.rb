class Pass::ApplicationError < StandardError
end
