class Pass::SecurityError < Pass::ApplicationError
  
end