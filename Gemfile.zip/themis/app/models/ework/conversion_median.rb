# -*- encoding : utf-8 -*-
class Ework::ConversionMedian < ActiveRecord::Base
  # attr_accessible :download_jar_ratio, :get_url_ratio, :launch_jar_ratio, :merge_jar_ratio, :seed_active_ratio, :seed_executed_ratio
end
