# -*- encoding : utf-8 -*-
module Charge
  def self.table_name_prefix
    'charge_'
  end
end
