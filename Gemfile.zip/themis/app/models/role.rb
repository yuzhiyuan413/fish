# -*- encoding : utf-8 -*-
class Role < ActiveRecord::Base
  include RedisCacheHelper
  #表关系
  has_and_belongs_to_many :accounts

  has_many :permissions, :as => :link, :dependent => :destroy, :order => "sort"

  attr_accessible :name, :description

  after_create :drop_dropdown_items_cache
  after_update :drop_dropdown_items_cache
  after_destroy :drop_dropdown_items_cache

end
