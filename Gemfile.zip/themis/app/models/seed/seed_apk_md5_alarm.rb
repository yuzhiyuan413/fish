# -*- encoding : utf-8 -*-
class Seed::SeedApkMd5Alarm < ActiveRecord::Base
  # attr_accessible id, uid, tag, md5, record_time, created_at, updated_at
  establish_connection "dwh_smart_#{Rails.env}"
  self.table_name = :seed_apk_md5_alarms
  attr_accessor :from_date, :end_date

  def search
    select_columns = ["md5", "count(distinct uid) uid_count"]
    conditions = {:tag => tag,
                  :record_time => Date.parse(from_date).beginning_of_day..Date.parse(end_date).end_of_day}
    group_columns = [:md5]
    Seed::SeedApkMd5Alarm.select(select_columns).where(conditions).group(group_columns)
  end

  def sum_record records
    return nil if records.blank?
    sum_record = OpenStruct.new([:records_size,:uid_count])
    sum_record.records_size = records.length
    sum_record.uid_count = records.map(&:uid_count).compact.sum
    sum_record
  end


  def self.tags conditions = nil
    ApkMd5AlarmReport.tags(conditions)
  end

end
