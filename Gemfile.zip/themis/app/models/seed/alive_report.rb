# -*- encoding : utf-8 -*-
class Seed::AliveReport < ActiveRecord::Base
	include Dg::GeneratorHelper
	attr_accessor :from_date, :end_date

	def search
		conditions = {:report_time => from_date..end_date}
		conditions[:tag] = System::TagGroup.tag_adaptor(Seed::AliveReport, tag) unless tag.eql?(System::TagGroup::TOTAL_OPTION_TAG)
		Seed::AliveReport.where(conditions).where("activation_num != 0").order([:tag,:report_time])
	end

	def stay_alive_avg records
		return nil if records.blank?
		idx = [2, 3, 7, 15, 30]
		result = []
		idx.each do |i|
			r = records.select{|r|r.report_time <= Date.today.ago(i.days).to_date}
			stay_alive_sum = r.map(&"stay_alive#{i}".to_sym).compact.sum
			activation_sum = r.map(&:activation_num).compact.sum
			stay_aliva_ratio = stay_alive_sum.blank? ? nil : (stay_alive_sum.to_f/activation_sum.to_f)
			result << {:idx => i, :activation_sum => activation_sum,
				:stay_alive_sum => stay_alive_sum, :stay_aliva_ratio => stay_aliva_ratio}
		end
		result
	end

	def avg_stay_alive=(avg_stay_alive)
	  write_attribute(:avg_stay_alive, avg_stay_alive.capitalize)
	end

	def avg_stay_alive
	  read_attribute(:avg_stay_alive).to_f
	end

	def self.avg_stay_alive key, value
		select("tag, sum(stay_alive#{key}) / sum(activation_num) as avg_stay_alive").where("report_time < ?",value).group(:tag).order("avg_stay_alive")
	end

	def self.tags conditions = nil
		select("distinct tag").where(conditions).order(:tag).map(&:tag).compact
	end
end
