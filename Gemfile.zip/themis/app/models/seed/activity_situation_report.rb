# -*- encoding : utf-8 -*-
class Seed::ActivitySituationReport < ActiveRecord::Base
  attr_accessible :record_time, :activation_num, :activity_num, :avg_request_times, :report_type, :request_times, :tag
  self.table_name = :activity_situation_reports
  def situation_reports
    items = %w{今日 昨日此时 昨日全天}
    situation_reports = []
    items.each do |item|
      if report_type.eql?('1')
        where_causes = {:tag => tag, :report_type => Seed::ActivityReport.to_s, :record_time => item }
        situation_reports << Seed::ActivitySituationReport.where(where_causes).first
      else
        where_causes = {:tag => tag, :product_version => '9.0', :record_time => item }
        situation_reports << Charge::SituationReport.where(where_causes).first
      end
    end
    situation_reports
  end

  def total_report
    if report_type.eql?('1')
      where_causes = {:tag => tag, :report_type => Seed::ActivityReport.to_s}
      Seed::ActivityTotalReport.where(where_causes)
    else
      where_causes = {:tag => tag, :product_version => '9.0'}
      Charge::SituationReport.where(where_causes)
    end
  end

  def self.tags conditions = nil
    select("distinct tag").where(conditions).order(:tag).map(&:tag).compact
  end
end
