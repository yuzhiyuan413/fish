# -*- encoding : utf-8 -*-
module Seed
  def self.table_name_prefix
    'seed_'
  end
end
