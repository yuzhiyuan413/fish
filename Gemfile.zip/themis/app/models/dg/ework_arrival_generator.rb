# -*- encoding : utf-8 -*-
class Dg::EworkArrivalGenerator < Dg::Generator

  include Dg::GeneratorHelper
  include Dg::EworkArrivalHelper

  def generate
    COL_TO_RECORD_METHOD.each do |col,method_name|
      records = self.method(method_name).call(*COL_TO_ARGS[col])
      ActiveRecord::Base.transaction do
        records.each do |record|
          r = Ework::ArrivalReport.find_or_initialize_by_report_date_and_tag(
            params[:date], record.tag)
          r.send("#{col}=", record.uid_count)
          r.save
        end
      end
    end

    summary_tags = System::TagGroup.distribute_sum_tags(Ework::ArrivalReport.tags)
    summary_tags.each do |summary_tag|
      tag_lbl = summary_tag.is_a?(Array) ? summary_tag.shift : summary_tag
      ActiveRecord::Base.transaction do
        COL_TO_COUNT_METHOD.each do |col, method_name|
          args = [summary_tag] + COL_TO_ARGS[col]
          uid_count = self.method(method_name).call(*args)
          r = Ework::ArrivalReport.find_or_initialize_by_report_date_and_tag(
          params[:date], tag_lbl)
          r.send("#{col}=", uid_count)
          r.save
        end
      end
    end

    update_ratio_sql = <<-EOF
      update ework_arrival_reports set
      seed_active_ratio=seed_active/ework_activation,
      seed_executing_ratio=seed_executing/ework_activation,
      seed_executied_ratio=seed_executied/ework_activation,
      seed_successed_ratio=seed_successed/ework_activation,
      seed_installed_ratio=seed_installed/ework_activation,
      seed_started_ratio=seed_started/ework_activation,
      v9_activity_ratio=v9_activity/ework_activation,
      seed_failed_ratio=seed_failed/seed_successed,
      seed_v8_exists_ratio=seed_v8_exists/seed_successed,
      seed_v9_exists_ratio=seed_v9_exists/seed_successed
      where report_date = '#{params[:date].to_s}'
    EOF
    conn = ActiveRecord::Base.establish_connection(Rails.env).connection
    conn.execute update_ratio_sql

    System::TagGroup.reset_tags_options_cache(Ework::ArrivalReport, System::Constant::PICK_OPTIONS[Ework::ArrivalReport])
  end

  private
    def activation_records
      getr(:ework).activation_records(params[:date].beginning_of_day)
    end

    def count_activation tag
      getr(:ework).count_activation(tag, params[:date].beginning_of_day)
    end

    def cross_solution_event_records event_id, conditions=nil
      getr(:ework).cross_solution_event_records(event_id,
        params[:date].beginning_of_day, params[:date].end_of_day, conditions)
    end

    def count_cross_solution_event tag, event_id, conditions=nil
      getr(:ework).count_cross_solution_event(tag, event_id,
        params[:date].beginning_of_day, params[:date].end_of_day, conditions)
    end

    def cross_v9_activity_records
      getr(:ework).cross_v9_activity_records(params[:date].beginning_of_day)
    end

    def count_cross_v9_activity tag
      getr(:ework).count_cross_v9_activity(tag, params[:date].beginning_of_day)
    end

end
