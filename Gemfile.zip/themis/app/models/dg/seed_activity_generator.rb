# -*- encoding : utf-8 -*-
class Dg::SeedActivityGenerator < Dg::Generator

	def generate

		er, sr, ar = embed_records, sign_records, activation_records

		ActiveRecord::Base.transaction do
			activity_records.each do |record|
				r = Seed::ActivityReport.find_or_initialize_by_report_time_and_tag(params[:date], record.tag)
				r.activity_num = record.uid
				r.request_num = record.id
				r.activation_num = ar.select{|x| x.activating_tag.eql?(record.tag) }.first.try(:uid).to_i
				r.embed_num = er.select{|x| x.tag.eql?(record.tag) }.first.try(:uid).to_i
				r.sign_num = sr.select{|x| x.tag.eql?(record.tag) }.first.try(:uid).to_i
				r.save
			end
		end

		summary_tags = System::TagGroup.distribute_sum_tags(Seed::ActivityReport.tags)
		ActiveRecord::Base.transaction do
			summary_tags.each do |tags|
				tag_lbl = tags.is_a?(Array) ? tags.shift : tags
				r = Seed::ActivityReport.find_or_initialize_by_report_time_and_tag(params[:date], tag_lbl)
				r.activity_num = count_activity(tags)
				r.request_num = count_request(tags)
				r.activation_num = count_activation(tags)
				r.embed_num = count_embed(tags)
				r.sign_num = count_sign(tags)
				r.save
			end
		end

		System::TagGroup.reset_tags_options_cache(Seed::ActivityReport, System::Constant::PICK_OPTIONS[Seed::ActivityReport])
	end

	private
	def activation_records
		getr(:seed).activation_records(params[:date].beginning_of_day, params[:date].end_of_day)
	end

	def activity_records
		getr(:request_history).activity_records(params[:date].beginning_of_day,params[:date].end_of_day)
	end

	def embed_records
		getr(:request_history).embed_records
	end

	def sign_records
		getr(:request_history).sign_records
	end

	def count_activity(tag)
		getr(:request_history).count_activity(tag,params[:date].beginning_of_day)
	end

	def count_embed(tag)
		getr(:request_history).count_embed(tag,params[:date].beginning_of_day)
	end

	def count_sign(tag)
		getr(:request_history).count_sign(tag,params[:date].beginning_of_day)
	end

	def count_request(tag)
		getr(:request_history).count_request(tag,params[:date].beginning_of_day)
	end

	def count_activation(tag)
		getr(:seed).count_activation(tag,params[:date].beginning_of_day)
	end

end
