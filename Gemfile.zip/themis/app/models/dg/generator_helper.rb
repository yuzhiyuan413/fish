# -*- encoding : utf-8 -*-
module Dg::GeneratorHelper
	def ratio dividend, divisor
		return 0 if divisor.nil? or dividend.nil? or divisor.zero? or dividend.zero?
		dividend.to_f/divisor.to_f
	end

	def date_range date, type
		dates = {}
		dates[2] = date.send(type, 1.days).to_date
		dates[3] = date.send(type, 2.days).to_date
		dates[7] = date.send(type, 6.days).to_date
		dates[15] = date.send(type, 14.days).to_date
		dates[30] = date.send(type, 29.days).to_date
		dates
	end


	def get_provinces
		provinces = [{:id=>1,:name=>"北京"},
		{:id=>2,:name=>"天津"},
		{:id=>3,:name=>"上海"},
		{:id=>4,:name=>"重庆"},
		{:id=>5,:name=>"河南"},
		{:id=>6,:name=>"河北"},
		{:id=>7,:name=>"山西"},
		{:id=>8,:name=>"内蒙古"},
		{:id=>9,:name=>"辽宁"},
		{:id=>10,:name=>"吉林"},
		{:id=>11,:name=>"黑龙江"},
		{:id=>12,:name=>"江苏"},
		{:id=>13,:name=>"浙江"},
		{:id=>14,:name=>"安徽"},
		{:id=>15,:name=>"福建"},
		{:id=>16,:name=>"江西"},
		{:id=>17,:name=>"山东"},
		{:id=>18,:name=>"湖北"},
		{:id=>19,:name=>"湖南"},
		{:id=>20,:name=>"广东"},
		{:id=>21,:name=>"广西"},
		{:id=>22,:name=>"海南"},
		{:id=>23,:name=>"四川"},
		{:id=>24,:name=>"贵州"},
		{:id=>25,:name=>"云南"},
		{:id=>26,:name=>"西藏"},
		{:id=>27,:name=>"陕西"},
		{:id=>28,:name=>"甘肃"},
		{:id=>29,:name=>"青海"},
		{:id=>30,:name=>"宁夏"},
		{:id=>31,:name=>"新疆"},
		{:id=>32,:name=>"香港"},
		{:id=>33,:name=>"澳门"},
		{:id=>34,:name=>"台湾"},
		{:id=>35,:name=>"国外"}].index_by{|r| r[:id].to_i}
			# provinces = Api::Location.new.get_all_provinces.index_by{|r| r[:id].to_i}
			provinces.each{|k, v| provinces[k] = v[:name] }
		  provinces["全部省份"] = "全部省份"
			provinces
	end

	def charge_report_conditions group_columns, record
		@provinces ||= get_provinces
		conditions = {}
		group_columns.each do |col|
			load_column = ModelMappings::CHARGE_COLUMN_MAPPING[col]
			conditions[load_column] = record.has_attribute?(col) ? attr_adaptor(record, col) : ModelMappings::CHARGE_SUM_PARAMS[col]
		end
		conditions
	end

	def combinations arr
		(0..arr.count).collect{|i| arr.combination(i).to_a }.flatten(1)
	end

	def attr_adaptor record, col
		col.eql?(:province_id) ? (@provinces[record.try(col)].nil? ? "其他省份" : @provinces[record.try(col)]) : record.try(col)
	end

	def tag_adapter record
		record.has_attribute?(:tag) ? record.tag : "全部标签"
	end

	def pv_adapter record
		record.has_attribute?(:loader_version_short) ? record.loader_version_short : "全部版本"
	end

	def params_adaptor launch_type
		params_model = ModelMappings::CHARGE_PARAMS_MODELS[launch_type].constantize
		extract_columns = ModelMappings::CHARGE_REPORT_COLUMNS[launch_type][:extract_column]
		load_columns = ModelMappings::CHARGE_REPORT_COLUMNS[launch_type][:load_columns]
		column_sets = []
		extract_columns.each do |column_name|
			column_set = ENV[column_name.to_s].try(:to_a) || params_model.select("distinct #{column_name.to_s}").map(&column_name).compact
			column_sets << column_set.unshift(ModelMappings::CHARGE_SUM_PARAMS[column_name])
		end
		gen_params_arr column_sets, load_columns
	end

	def gen_params_arr column_sets, load_columns
		result = column_sets.shift
		while not column_sets.empty?
			set_x = column_sets.shift
			result = descartes(result, set_x);
		end
		result.collect do |r|
			r.flatten!
			param = {}
			r.each.each_with_index{|val,idx| param[load_columns[idx]] = val}
			param
		end
	end

	def descartes set_x, set_y
		result = []
		set_x.each do |x|
			set_y.each do |y|
				result << [x,y]
			end
		end
		result
	end
end
