# -*- encoding : utf-8 -*-
class Dg::InitSeedAliveUsersGenerator < Dg::Generator

	include Dg::GeneratorHelper

	def generate
		dates = date_range(params[:date], :since)
		r = Seed::AliveReport.find_or_initialize_by_report_time_and_tag(params[:date], params[:tag_name])
		r.activation_num = seed_activation_num
		r.stay_alive2	= stay_alive(dates[2], 2)
		r.stay_alive3	= stay_alive(dates[3], 3)
		r.stay_alive7	= stay_alive(dates[7], 7)
		r.stay_alive15	= stay_alive(dates[15], 15)
		r.stay_alive30	= stay_alive(dates[30], 30)
		r.save
	end

	private
	def seed_activation_num
		getr(:seed).count_activation(params[:tag], params[:date].beginning_of_day)
	end

	def stay_alive(date, day)
		begin_date = date
		end_date = date.tomorrow
		LOG.info "标签#{params[:tag_name]},根据激活日期#{params[:date].to_s},生成#{begin_date.to_s}到#{end_date.to_s}的seed的#{day}日留存数据"
		getr(:request_history).stay_alive(params[:date], date)
	end

end
