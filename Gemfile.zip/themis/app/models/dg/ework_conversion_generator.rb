# -*- encoding : utf-8 -*-
class Dg::EworkConversionGenerator < Dg::Generator

  include Dg::GeneratorHelper

  def generate

    event_to_event_id = {
      :active => "active",
      :solution_executing => "solution_executing"
    }

    event_to_setter_func = {
      :active => "seed_active=",
      :solution_executing => "seed_executed="
    }

    event_to_aid_setter_func = {
      :active => "seed_active_aid=",
      :solution_executing => "seed_executed_aid="
    }

    ActiveRecord::Base.transaction do
      conversion_records.each do |record|
        r = Ework::ConversionReport.find_or_initialize_by_report_date_and_tag(
          params[:date], record.tag)
        r.app_activation = record.app_activation
        r.get_url = record.get_url
        r.download_jar = record.download_jar
        r.merge_jar = record.merge_jar
        r.launch_jar = record.launch_jar
        r.save
      end
    end

    ActiveRecord::Base.transaction do
      summary_tags = System::TagGroup.distribute_sum_tags(Ework::ConversionReport.tags)
      summary_tags.each do |summary_tag|
        tag_lbl = summary_tag.is_a?(Array) ? summary_tag.shift : summary_tag
        records = count_conversion(summary_tag)
        records.each do |record|
          r = Ework::ConversionReport.find_or_initialize_by_report_date_and_tag(
          params[:date], tag_lbl)
          r.app_activation = record.app_activation
          r.get_url = record.get_url
          r.download_jar = record.download_jar
          r.merge_jar = record.merge_jar
          r.launch_jar = record.launch_jar
          r.save
        end
      end
    end


    ActiveRecord::Base.transaction do
      event_to_event_id.each do |event_name, event_id|
        records = event_sum_records(event_id)
        records.each do |record|
          r = Ework::ConversionReport.find_or_initialize_by_report_date_and_tag(
            params[:date], record.tag)
          r.send(event_to_setter_func[event_name], record.did_count)
          r.save
        end
      end
    end

    ActiveRecord::Base.transaction do
      gen_summary_tags.each do |summary_tag|
        tag_lbl = summary_tag.is_a?(Array) ? summary_tag.shift : summary_tag
        event_to_event_id.each do |event_name, event_id|
          did_count = count_event_sum_by_tag_group(summary_tag, event_id)
          r = Ework::ConversionReport.find_or_initialize_by_report_date_and_tag(
            params[:date], tag_lbl)
          r.send(event_to_setter_func[event_name], did_count)
          r.save
        end
      end
    end

    ActiveRecord::Base.transaction do
      event_to_event_id.each do |event_name, event_id|
        records = seed_event_records(event_id)
        records.each do |record|
          r = Ework::ConversionReport.find_or_initialize_by_report_date_and_tag(
          params[:date], record.tag)
          r.send(event_to_aid_setter_func[event_name], record.uid_count)
          r.save
        end
      end
    end

    ActiveRecord::Base.transaction do
      gen_summary_tags.each do |summary_tag|
        tag_lbl = summary_tag.is_a?(Array) ? summary_tag.shift : summary_tag
        event_to_event_id.each do |event_name, event_id|
          aid_count = count_seed_event_cross_ework(summary_tag, event_id)
          r = Ework::ConversionReport.find_or_initialize_by_report_date_and_tag(
          params[:date], tag_lbl)
          r.send(event_to_aid_setter_func[event_name], aid_count)
          r.save
        end
      end
    end

    update_ratio_sql = <<-EOF
      update ework_conversion_reports set
      get_url_ratio = get_url/app_activation,
      download_jar_ratio = download_jar/app_activation,
      merge_jar_ratio = merge_jar/app_activation,
      launch_jar_ratio = launch_jar/app_activation,
      seed_active_ratio = seed_active/app_activation,
      seed_executed_ratio = seed_executed/app_activation,
      seed_active_aid_ratio = seed_active_aid/app_activation,
      seed_executed_aid_ratio = seed_executed_aid/app_activation
      where report_date = '#{params[:date].to_s}'
    EOF
    conn = ActiveRecord::Base.establish_connection(Rails.env).connection
    conn.execute update_ratio_sql

    System::TagGroup.reset_tags_options_cache(Ework::ConversionReport, System::Constant::PICK_OPTIONS[Ework::ConversionReport])
  end

  private
    def gen_summary_tags
      summary_tags = System::TagGroup.distribute_sum_tags(app_tags)
      summary_tags.delete(System::TagGroup::TOTAL_SUM_TAG)
      summary_tags << [System::TagGroup::TOTAL_SUM_TAG, app_tags].flatten
      summary_tags
    end

    def app_tags
      tags = Ework::ConversionReport.tags({:report_date => params[:date]})
      tags.tap{|x| x.delete(System::TagGroup::TOTAL_SUM_TAG) }
    end

    def conversion_records
      getr(:ework).conversion_records(params[:date].beginning_of_day)
    end

    def count_conversion tag
      getr(:ework).count_conversion(tag, params[:date].beginning_of_day)
    end

    def count_event_sum_by_tag_group tag, event_id
      getr(:sword_solution_event).count_event_sum_by_tag_group(tag, event_id,
        params[:date].beginning_of_day, params[:date].end_of_day)
    end

    def event_sum_records event_id
      getr(:sword_solution_event).event_sum_records(event_id,
        params[:date].beginning_of_day, params[:date].end_of_day, {:tag => app_tags })
    end

    def count_seed_event_cross_ework tag, solution_event_id
      getr(:ework).count_seed_event_cross_ework(tag, solution_event_id, params[:date].beginning_of_day)
    end

    def seed_event_records solution_event_id
      getr(:ework).seed_event_records(solution_event_id, params[:date].beginning_of_day)
    end

end
