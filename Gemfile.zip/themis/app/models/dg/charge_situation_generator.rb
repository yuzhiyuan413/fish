# -*- encoding : utf-8 -*-
class Dg::ChargeSituationGenerator < Dg::Generator

	include Dg::GeneratorHelper
	include ChargeHelper

	def generate
		clean_overdue_data

		yesterday_at_this_time = charge_max_request_time.blank? ? Time.now.ago(1.day) : charge_max_request_time.ago(1.day)
		activation_today, activation_yesterday = activation_situation_records(Date.today), activation_situation_records(Date.yesterday)
		activity_today, activity_yesterday = activity_situation_records(Date.today), activity_situation_records(Date.yesterday)

		activation_situation_reports = {
				"今日" => activation_today,
				"昨日全天" => activation_yesterday
		}
		activity_situation_reports = {
				"今日" => activity_today,
				"昨日全天" => activity_yesterday
		}

		ActiveRecord::Base.transaction do
			activation_situation_reports.each do |record_time, records|
				records.each do |record|
					r = Charge::SituationReport.find_or_initialize_by_record_time_and_tag_and_product_version(
					record_time, record.tag, record.product_version)
					r.activation_num = record.activation_num
					r.save
				end
			end
			activity_situation_reports.each do |record_time, records|
				records.each do |record|
					r = Charge::SituationReport.find_or_initialize_by_record_time_and_tag_and_product_version(
						record_time, record.tag, record.product_version)
					r.activity_num = record.activity_num
					r.request_times = record.request_times
					r.avg_request_times = record.request_per_avg
					r.save
				end
			end

			columns = ["charge_users.tag", "charge_users.loader_version_short"]
			(0..columns.count).collect{|i| columns.combination(i).to_a }.flatten(1).each do |group_columns|
				activation_yatt = activation_records(yesterday_at_this_time.beginning_of_day, yesterday_at_this_time, group_columns)
				activation_yatt.each do |record|
					r = Charge::SituationReport.find_or_initialize_by_record_time_and_tag_and_product_version(
					"昨日此时", tag_adapter(record), pv_adapter(record))
					r.activation_num = record.activation_num
					r.save
				end
			end

			columns = ["tag", "loader_version_short"]
			conditions = {:request_time => (yesterday_at_this_time.beginning_of_day..yesterday_at_this_time) }
			select_columns = ["count(id) request_times", "count(distinct uuid) activity_num" ]
			(0..columns.count).collect{|i| columns.combination(i).to_a }.flatten(1).each do |group_columns|
				activity_yatt = ChargeDs::ChargeRequestHistory.select(select_columns + group_columns).where(conditions).group(group_columns)
				activity_yatt.each do |record|
					r = Charge::SituationReport.find_or_initialize_by_record_time_and_tag_and_product_version(
					"昨日此时", tag_adapter(record), pv_adapter(record))
					r.activity_num = record.activity_num
					r.request_times = record.request_times
					r.avg_request_times = ratio(record.request_times, record.activity_num)
					r.save
				end
			end
		end
		reset_charge_options_cache(Charge::SituationReport)

	end

	private
		def clean_overdue_data
			Charge::SituationReport.destroy_all("updated_at < #{params[:date].yesterday.to_s}")
		end

		def activation_records begin_time, end_time, group_columns
			getr(:charge_activation).activation_records(begin_time, end_time, group_columns)
		end

		def activity_records begin_time, end_time, group_columns
			getr(:charge_activity).activity_records(begin_time, end_time, group_columns)
		end

		def activation_situation_records report_date
			getr(:charge_activation).activation_situation_records(report_date)
		end

		def activity_situation_records report_date
			getr(:charge_activity).activity_situation_records(report_date)
		end

		def charge_max_request_time
			getr(:charge_activity).charge_max_request_time
		end

end
