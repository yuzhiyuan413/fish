# -*- encoding : utf-8 -*-
class Dg::MediansGenerator < Dg::Generator
	include Dg::GeneratorHelper

	def generate
		medians = %w{Seed::AliveReport}
		dates = date_range(Date.today, :ago)
		stay_alive_idx = %w{2 3 7 15 30}
		medians.each do |mdl|
			median = Median.find_or_initialize_by_name(mdl)
			dates.each do |key, value|
				median.send("median_ratio#{key}=", avg_stay_alive(mdl, key, value))
			end
			median.save
		end
	end

	def avg_stay_alive mdl, key, value
		getr(:median).avg_stay_alive mdl, key, value
	end
end
