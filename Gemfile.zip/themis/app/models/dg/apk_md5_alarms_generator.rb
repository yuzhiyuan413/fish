# -*- encoding : utf-8 -*-
class Dg::ApkMd5AlarmsGenerator < Dg::Generator
	def generate
		sql = <<-EOF
			select c.activating_tag as tag, count(distinct a.uid) as count
			from seed_request_histories a
			inner join users c on a.uid = c.current_uuid
			left join package_infos b on a.samd = b.md5
			where b.md5 is null group by c.activating_tag;
		EOF
		result = ActiveRecord::Base.establish_connection("dwh_smart_#{Rails.env}").connection.execute sql
		result_struct = OpenStruct.new(result.fields)
		records = result.collect do |item|
			r = result_struct.dup
			item.to_enum.each_with_index do |val, idx|
				r.send("#{result.fields[idx]}=", val)
			end
			r
		end
		records.each do |record|
			r = ApkMd5AlarmReport.find_or_initialize_by_tag(record.tag)
			r.tag_created_at = tag_created_at record.tag
			r.user_total_count = count_activation_by_tag(record.tag)
	 		r.abnormal_user_count = record.count
			r.save
		end

		System::TagGroup.reset_tags_options_cache(Seed::SeedApkMd5Alarm, System::Constant::PICK_OPTIONS[Seed::SeedApkMd5Alarm])
	end

	def find_abnormal_tags
		getr(:apk_md5_alarms).find_abnormal_tags
	end

	def count_activation_by_tag abnormal_tag
		getr(:seed).count_activation_by_tag abnormal_tag
	end

	def tag_created_at abnormal_tag
		getr(:apk_md5_alarms).tag_created_at abnormal_tag
	end

end
