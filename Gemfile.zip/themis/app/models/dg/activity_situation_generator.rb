# -*- encoding : utf-8 -*-
class Dg::ActivitySituationGenerator < Dg::Generator

	include Dg::GeneratorHelper

	def generate
		clean_overdue_data

		seed_activity_yesterday = seed_max_record_time.blank? ? Time.now.ago(1.day) : seed_max_record_time.ago(1.day)
		seed_activation_yesterday = seed_max_activation_time.blank? ? Time.now.ago(1.day) : seed_max_activation_time.ago(1.day)
		sast = seed_activity_situation_records(Date.today)
		sasy = seed_activity_situation_records(Date.yesterday)
		sar = seed_activity_records(seed_activity_yesterday)
		savr = seed_activation_records(seed_activation_yesterday)

		ActiveRecord::Base.transaction do
			{"今日" => sast, "昨日全天" => sasy}.each do |record_time, records|
				records.each do |record|
					r = Seed::ActivitySituationReport.find_or_initialize_by_report_type_and_record_time_and_tag(
						Seed::ActivityReport.to_s, record_time, record.tag)
					r.activity_num = record.activity_num
					r.activation_num = record.activation_num
					r.request_times = record.request_num
					r.avg_request_times = ratio(record.request_num, record.activity_num)
					r.save
				end
			end
		end

		ActiveRecord::Base.transaction do
			sar.each do |record|
				r = Seed::ActivitySituationReport.find_or_initialize_by_report_type_and_record_time_and_tag(
					Seed::ActivityReport.to_s, "昨日此时", record.tag)
				r.activity_num = record.uid
				r.activation_num = savr.select{|x| x.activating_tag.eql?(record.tag) }.first.try(:uid).to_i
				r.request_times = record.id
				r.avg_request_times = ratio(record.id, record.uid)
				r.save
			end
		end

		summary_tags = System::TagGroup.distribute_sum_tags(Seed::ActivitySituationReport.tags)
		ActiveRecord::Base.transaction do
			summary_tags.each do |tags|
				tag_lbl = tags.is_a?(Array) ? tags.shift : tags
				r = Seed::ActivitySituationReport.find_or_initialize_by_report_type_and_record_time_and_tag(
					Seed::ActivityReport.to_s, "昨日此时", tag_lbl)
				r.activity_num = count_activity_num_by_tags_at_ytm(Seed::ActivityReport.to_s, tags, seed_activity_yesterday)
				r.activation_num = count_activation_num_by_tags_ytm(Seed::ActivityReport.to_s, tags, seed_activation_yesterday)
				r.request_times = count_request_times_by_tags_ytm(Seed::ActivityReport.to_s, tags, seed_activity_yesterday)
				r.avg_request_times = ratio(r.request_times, r.activity_num)
				r.save
			end
		end

		System::TagGroup.reset_tags_options_cache(Seed::ActivitySituationReport, System::Constant::PICK_OPTIONS[Seed::ActivitySituationReport])
	end

	private
	def clean_overdue_data
		Seed::ActivitySituationReport.destroy_all("updated_at < #{params[:date].yesterday.to_s}")
	end

	def seed_activity_situation_records report_date
		getr(:activity).seed_activity_situation_records report_date
	end

	def seed_activity_records report_time
		getr(:request_history).activity_records(report_time.beginning_of_day,report_time)
	end

	def count_activity_num_by_tags_at_ytm(report_type, tags, end_time)
		getr(:activity).count_activity_num_by_tags_at_ytm(report_type, tags, end_time)
	end

	def count_activation_num_by_tags_ytm(report_type, tags, end_time)
		getr(:activity).count_activation_num_by_tags_ytm(report_type, tags, end_time)
	end

	def count_request_times_by_tags_ytm(report_type, tags, end_time)
		getr(:activity).count_request_times_by_tags_ytm(report_type, tags, end_time)
	end

	def seed_activation_records report_time
		getr(:seed).activation_records(report_time.beginning_of_day,report_time)
	end

	def seed_max_record_time
		getr(:request_history).max_record_time
	end

	def seed_max_activation_time
		getr(:seed).max_activation_time
	end
end
