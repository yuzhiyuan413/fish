# -*- encoding : utf-8 -*-
class Dg::ChargeTotalGenerator < Dg::Generator
	include Dg::GeneratorHelper

	def generate
		clean_overdue_data

		activation_yesterday_reports = activation_situation_records(Date.yesterday)
		activity_yesterday_reports = activity_situation_records(Date.yesterday)
		ActiveRecord::Base.transaction do
			activation_yesterday_reports.each do |record|
				r = Charge::TotalReport.find_or_initialize_by_tag_and_product_version(record.tag, record.product_version)
				r.yesterday_activation_num = record.activation_num
				r.save
			end
			activity_yesterday_reports.each do |record|
				r = Charge::TotalReport.find_or_initialize_by_tag_and_product_version(record.tag, record.product_version)
				r.yesterday_activity_num = record.activity_num
				r.save
			end

			columns = ["charge_users.tag", "charge_users.loader_version_short"]
			(0..columns.count).collect{|i| columns.combination(i).to_a }.flatten(1).each do |group_columns|
				total_activation_records = total_activation_records(group_columns)
				total_activation_records.each do |record|
					r = Charge::TotalReport.find_or_initialize_by_tag_and_product_version(tag_adapter(record), pv_adapter(record))
					r.total_activation_num = record.activation_num
					r.save
				end

				activity7_records = activity_records(7.days.ago.beginning_of_day, Time.now, group_columns)
				activity7_records.each do |record|
					r = Charge::TotalReport.find_or_initialize_by_tag_and_product_version(tag_adapter(record), pv_adapter(record))
					r.activity7 = record.activity_num
					r.save
				end

				activity30_records = activity_records(30.days.ago.beginning_of_day, Time.now, group_columns)
				activity30_records.each do |record|
					r = Charge::TotalReport.find_or_initialize_by_tag_and_product_version(tag_adapter(record), pv_adapter(record))
					r.activity30 = record.activity_num
					r.save
				end
			end
		end
	end

	private
		def clean_overdue_data
			Charge::TotalReport.destroy_all("updated_at < #{params[:date].yesterday.to_s}")
		end

		def activation_situation_records report_date
			getr(:charge_activation).activation_situation_records(report_date)
		end

		def activity_situation_records report_date
			getr(:charge_activity).activity_situation_records(report_date)
		end

		def total_activation_records group_columns
			getr(:charge_activation).total_activation_records(group_columns)
		end

		def activity_records begin_time, end_time, group_columns
			getr(:charge_activity).activity_records(begin_time, end_time, group_columns)
		end

end
