# -*- encoding : utf-8 -*-
class Dg::SeedDeviceDetailGenerator < Dg::Generator 

  include Dg::GeneratorHelper

  OTHERS_MODEL_NAME = '其他型号'
  SUMMARY_MODEL_NAME = '型号汇总'
  TOP_MODEL_LIMIT = 30

  attr_accessor :top_models

  def initialize
    @top_models = {}
  end
  def generate
    clean_overdue_data
    #根据标签分组，将不同机型的总数插入数据库，每个机型超过30条记录为其他机型
    ActiveRecord::Base.transaction do
      save_count_reports(device_detail_records.group_by(&:tag))
    end
    grouped_count_records={}
    summary_tags = System::TagGroup.distribute_sum_tags(Seed::DeviceDetailReport.tags)
    summary_tags.each do |tag|
      tag_name = tag.is_a?(Array) ? tag.shift : tag
      grouped_count_records[tag_name] = device_detail_records_by_tag_group(tag)
    end
    #根据型号和机名分组，统计汇总数据插入数据库
    ActiveRecord::Base.transaction do
      save_count_reports(grouped_count_records)
    end


    ActiveRecord::Base.transaction do
      device_sum_records.each do |record|
        r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
          params[:date], record.tag, nil, SUMMARY_MODEL_NAME)
        r.count = record.did_count
        r.save
      end
    end
    summary_tags = System::TagGroup.distribute_sum_tags(Seed::DeviceDetailReport.tags)
    ActiveRecord::Base.transaction do
      summary_tags.each do |tag|
        tag_name = tag.is_a?(Array) ? tag.shift : tag
        r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
          params[:date], tag_name, nil, SUMMARY_MODEL_NAME)
        r.count = count_device_sum_by_tag_group(tag)
        r.save
      end
    end

    ActiveRecord::Base.transaction do
      save_succ_count_reports(device_detail_succ_records.group_by(&:tag))
    end
    grouped_succ_count_records={}
    summary_tags = System::TagGroup.distribute_sum_tags(Seed::DeviceDetailReport.tags)
    summary_tags.each do |tag|
      tag_name = tag.is_a?(Array) ? tag.shift : tag
      grouped_succ_count_records[tag_name] = device_detail_succ_records_by_tag_group(tag)
    end
    ActiveRecord::Base.transaction do
      save_succ_count_reports(grouped_succ_count_records)
    end

    ActiveRecord::Base.transaction do
      device_succ_sum_records.each do |record|
        r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
          params[:date], record.tag, nil, SUMMARY_MODEL_NAME)
        r.success_count = record.did_count
        r.save
      end
    end

    summary_tags = System::TagGroup.distribute_sum_tags(Seed::DeviceDetailReport.tags)
    ActiveRecord::Base.transaction do
      summary_tags.each do |tag|
        tag_name = tag.is_a?(Array) ? tag.shift : tag
        r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
          params[:date], tag_name, nil, SUMMARY_MODEL_NAME)
        r.success_count = count_device_succ_sum_by_tag_group(tag)
        r.save
      end
    end

    succ_proportion_ratio_sql = <<-EOF
      update seed_device_detail_reports a,
      (select tag, count, success_count from seed_device_detail_reports
      where report_date = '#{params[:date].to_s}' and model = '#{SUMMARY_MODEL_NAME}') b
      set a.succ_proportion_ratio = if(b.success_count=0,0,a.success_count/b.success_count),
      a.proportion_ratio = if(b.count=0,0,a.count/b.count)
      where a.report_date = '#{params[:date].to_s}' and a.tag = b.tag
    EOF
    success_ratio_sql = <<-EOF
      update seed_device_detail_reports
      set success_ratio = if(count=0,0,success_count/count)
      where report_date = '#{params[:date].to_s}'
    EOF
    conn = ActiveRecord::Base.establish_connection(Rails.env).connection
    
    
    conn.execute succ_proportion_ratio_sql
    conn.execute success_ratio_sql
    #System::TagGroup.reset_tags_options_cache(Seed::DeviceDetailReport, System::Constant::PICK_OPTIONS[Seed::DeviceDetailReport])
  end

  private
    def clean_overdue_data
      Seed::DeviceDetailReport.destroy_all(:report_date => params[:date])
    end

    def save_count_reports grouped_count_records
      grouped_count_records.each do |tag, records|
        sorted_records = records.sort_by(&:did_count)
        top_records = sorted_records.pop(TOP_MODEL_LIMIT)
        top_models[tag] = top_records.collect{|x| [x.brand, x.model].join}
        others_sum_count = sorted_records.blank? ? 0  : sorted_records.map(&:did_count).compact.sum
        top_records.each do |record|
          r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
            params[:date], tag, record.brand, record.model)
          r.count = record.did_count
          r.save
        end
        r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
          params[:date], tag, nil, OTHERS_MODEL_NAME)
        r.count = others_sum_count
        r.save
      end
    end

    def save_succ_count_reports grouped_succ_count_records
      grouped_succ_count_records.each do |tag, records|
        top_records = []
        other_records = []
        records.each do |r|
          if top_models[tag].include?([r.brand, r.model].join)
            top_records << r
          else
            other_records << r
          end
        end
        others_sum_count = other_records.blank? ? 0  : other_records.map(&:did_count).compact.sum
        top_records.each do |record|
          r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
            params[:date], tag,  record.brand, record.model)
          r.success_count = record.did_count
          r.save
        end
        r = Seed::DeviceDetailReport.find_or_initialize_by_report_date_and_tag_and_brand_and_model(
          params[:date], tag,  nil, OTHERS_MODEL_NAME)
        r.success_count = others_sum_count
        r.save
      end
    end

    def device_detail_records_by_tag_group(tag)
      getr(:sword_device).device_detail_records_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def device_detail_records
      getr(:sword_device).device_detail_records(params[:date].beginning_of_day)
    end

    def count_device_sum_by_tag_group(tag)
      getr(:sword_device).count_device_sum_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def device_sum_records
      getr(:sword_device).device_sum_records(params[:date].beginning_of_day)
    end


    def device_detail_succ_records
      getr(:sword_device).device_detail_succ_records(params[:date].beginning_of_day)
    end

    def device_detail_succ_records_by_tag_group(tag)
      getr(:sword_device).device_detail_succ_records_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def count_device_succ_sum_by_tag_group(tag)
      getr(:sword_device).count_device_succ_sum_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def device_succ_sum_records
      getr(:sword_device).device_succ_sum_records(params[:date].beginning_of_day)
    end
end