# -*- encoding : utf-8 -*-
class Dg::SeedActivationGenerator < Dg::Generator

	include Dg::GeneratorHelper

	def generate

		attr_records ={
			"seed_activation_num" => group_activation_tag,
			"panda_activation_num" => cross_panda_group_activation_by_tag,
			 "old_user_active_num" => group_old_user_activation_by_tag,
			"old_user_activity_num" => group_old_user_activity_by_tag,
			"bash_activation_num" => group_charge_user_conversion_by_tag
		}
 
		ActiveRecord::Base.transaction do
			attr_records.each do |attr, records|
				records.each do |record|
					r = Seed::ActivationReport.find_or_initialize_by_report_time_and_tag(params[:date], record.activating_tag)
					r.send("#{attr}=", record.uid)
					r.save
				end
			end
	 end

		report_tags = Seed::ActivationReport.tags
		ActiveRecord::Base.transaction do
			attr_records.keys.each do |attr|
				System::TagGroup.distribute_sum_tags(report_tags).each do |tag|
					tag_lbl = tag.is_a?(Array) ? tag.shift : tag
					uid_count = self.method(attr).call(tag)
					r = Seed::ActivationReport.find_or_initialize_by_report_time_and_tag(params[:date], tag_lbl)
					r.send("#{attr}=", uid_count)
					r.save
				end
			end
		end

		update_ratio_attrs
		# update_partner

		# System::TagGroup.reset_tags_options_cache(Seed::ActivationReport, System::Constant::PICK_OPTIONS[Seed::ActivationReport])
	end

	private
	def update_ratio_attrs
		update_ratio_attrs_sql = <<-EOF
			update seed_activation_reports
			set signature_ratio = (signature_num/seed_activation_num),
			bash_activation_ratio = (bash_activation_num/seed_activation_num)
			where report_time = '#{params[:date].to_s}'
		EOF
		conn = ActiveRecord::Base.establish_connection(Rails.env).connection
		conn.execute update_ratio_attrs_sql
	end

	def update_partner
		all_tags = Seed::ActivationReport.tags({:report_time => (params[:date].beginning_of_day..params[:date].end_of_day)})
		product_tag_service = Api::ProductTag.new
		partners ={}
		all_tags.each do |tag|
			partners[tag] = product_tag_service.get_partner_by_tag_name(tag)
		end
		ActiveRecord::Base.transaction do
			update_time_range = (params[:date].beginning_of_day..params[:date].end_of_day)
			partners.each do |tag, partner|
				Seed::ActivationReport.where({:report_time => update_time_range, :tag => tag }).update_all(
					:partner => partner)
			end
		end
	end

	def group_old_user_activation_by_tag
		getr(:panda).group_old_user_activation_by_tag params[:date]
	end

	def group_old_user_activity_by_tag
		getr(:seed).group_old_user_activity_by_tag params[:date].beginning_of_day
	end

	def cross_panda_group_activation_by_tag
		getr(:seed).cross_panda_group_activation_by_tag params[:date].beginning_of_day
	end

	def group_sign_by_tag
		getr(:seed).group_sign_by_tag params[:date].beginning_of_day
	end

	def group_reset_by_tag
		getr(:seed).group_reset_by_tag params[:date].beginning_of_day
	end

	def group_activation_tag
		getr(:seed).activation_records(params[:date].beginning_of_day, params[:date].end_of_day)
	end

	def group_charge_user_conversion_by_tag
		getr(:seed).group_charge_user_conversion_by_tag(params[:date].beginning_of_day)
	end

	def seed_activation_num tag
		getr(:seed).count_activation(tag, params[:date].beginning_of_day)
	end

	def panda_activation_num tag
		getr(:seed).count_activation_cross_panda(tag, params[:date].beginning_of_day)
	end

	def signature_num tag
		getr(:seed).count_signature(tag, params[:date].beginning_of_day)
	end

	def old_user_active_num tag
		getr(:panda).count_old_user_activation(tag, params[:date])
	end

	def old_user_activity_num tag
		getr(:seed).count_old_user_activity(tag, params[:date].beginning_of_day)
	end

	def bash_activation_num tag
		getr(:seed).v9_activation_num(tag, params[:date].beginning_of_day)
	end

end
