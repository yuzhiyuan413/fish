# -*- encoding : utf-8 -*-
module Dg::SeedArrivalHelper

  COL_TO_ARGS={
    :seed_activation => [],
    :seed_active => ["active"],
    :seed_executing => ["solution_executing"],
    :seed_executied => ["solution_executed"],
    :seed_successed => ["solution_executed", "sword_production.seed_feedback_histories.excuted_status = 'Success'"],
    :seed_installed => ["solution_executed", "sword_production.seed_feedback_histories.nut_code in (0,16,17)" ],
    :seed_started => ["solution_executed", "sword_production.seed_feedback_histories.nut_code in (0,17) "],
    :seed_failed => ["solution_executed","sword_production.seed_feedback_histories.nut_code not in (0,2,4,16,17)"],
    :seed_v8_exists => ["solution_executed", "sword_production.seed_feedback_histories.nut_code = 2 "],
    :seed_v9_exists => ["solution_executed", "sword_production.seed_feedback_histories.nut_code = 4 "],
    :v9_activity => []
  }

  COL_TO_RECORD_METHOD={
    :seed_activation => "activation_records",
    :seed_active => "cross_solution_event_records",
    :seed_executing => "cross_solution_event_records",
    :seed_executied => "cross_solution_event_records",
    :seed_successed => "cross_solution_event_records",
    :seed_installed => "cross_solution_event_records",
    :seed_started => "cross_solution_event_records",
    :seed_failed => "cross_solution_event_records",
    :seed_v8_exists => "cross_solution_event_records",
    :seed_v9_exists => "cross_solution_event_records",
    :v9_activity => "cross_v9_activity_records"
  }

  COL_TO_COUNT_METHOD={
    :seed_activation => "count_activation",
    :seed_active => "count_cross_solution_event",
    :seed_executing => "count_cross_solution_event",
    :seed_executied => "count_cross_solution_event",
    :seed_successed => "count_cross_solution_event",
    :seed_installed => "count_cross_solution_event",
    :seed_started => "count_cross_solution_event",
    :seed_failed => "count_cross_solution_event",
    :seed_v8_exists => "count_cross_solution_event",
    :seed_v9_exists => "count_cross_solution_event",
    :v9_activity => "count_cross_v9_activity"
  }
end
