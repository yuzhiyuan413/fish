# -*- encoding : utf-8 -*-
class Dg::ChargeActivityOperatorGenerator < Dg::Generator

  include Dg::GeneratorHelper
  include ChargeHelper

  def generate

    where_clause = {:request_time => (params[:date].beginning_of_day..params[:date].end_of_day) }
    group_columns = [:province_id, :tag, :loader_version_short]
    select_columns = ["count(distinct uuid) uuid"]
    group_clauses = (0..group_columns.count).collect{|i| group_columns.combination(i).to_a }.flatten(1).collect{|i| i << :operator_id}
    group_clauses.each do |group_clause|
      select_clause = select_columns + group_clause
      records = ChargeDs::ChargeRequestHistory.select(select_clause).where(where_clause).group(group_clause)
      records.each do |record|
        find_conditions = charge_report_conditions group_columns, record
        find_conditions[:report_date] = params[:date]
        r = Charge::ActivityReport.find_or_initialize_by_report_date_and_tag_and_product_version_and_province(
          find_conditions)
        r.send(ModelMappings::OPERATOR_ID_TO_ATTR_WRITE[record.operator_id], record.uuid)
        r.save
      end
    end
    reset_charge_options_cache(Charge::ActivityReport)
  end

end
