# -*- encoding : utf-8 -*-
class Dg::SeedAliveUsersGenerator < Dg::Generator

	include Dg::GeneratorHelper

	def generate

		activation_dates = date_range(params[:date], :ago)
		ActiveRecord::Base.transaction do
			activation_dates.each do |k,v|
				sar = stay_alive_records(v, params[:date])
				sar.each do |record|
					r = Seed::AliveReport.find_or_initialize_by_report_time_and_tag(v, record.tag)
					r.send("stay_alive#{k}=", record.uid)
					r.save
				end
			end
		end
		summary_tags = System::TagGroup.distribute_sum_tags(Seed::AliveReport.tags)
		ActiveRecord::Base.transaction do
			summary_tags.each do |tag|
				tag_lbl = tag.is_a?(Array) ? tag.shift : tag
				activation_dates.each do |k,v|
					r = Seed::AliveReport.find_or_initialize_by_report_time_and_tag(v, tag_lbl)
					r.send("stay_alive#{k}=", count_stay_alive(tag, v, params[:date]))
					r.save
				end
			end
		end

		ar = activation_records
		ActiveRecord::Base.transaction do
			ar.each do |record|
				r = Seed::AliveReport.find_or_initialize_by_report_time_and_tag(params[:date], record.activating_tag)
				r.activation_num = record.uid
				r.save
			end
		end
		summary_tags = System::TagGroup.distribute_sum_tags(Seed::AliveReport.tags)
		ActiveRecord::Base.transaction do
			summary_tags.each do |tag|
				tag_lbl = tag.is_a?(Array) ? tag.shift : tag
				r = Seed::AliveReport.find_or_initialize_by_report_time_and_tag(params[:date], tag_lbl)
				r.activation_num = count_activation(tag)
				r.save
			end
		end

		System::TagGroup.reset_tags_options_cache(Seed::AliveReport, System::Constant::PICK_OPTIONS[Seed::AliveReport])

	end

	private
		def stay_alive_records(activation_date, stay_alive_date)
			getr(:request_history).stay_alive_records(activation_date, stay_alive_date)
		end

		def count_stay_alive(tag, activation_date, stay_alive_date)
			getr(:request_history).count_stay_alive(tag, activation_date, stay_alive_date)
		end

		def activation_records
			getr(:seed).activation_records(params[:date].beginning_of_day, params[:date].end_of_day)
		end

		def count_activation tag
			getr(:seed).count_activation(tag, params[:date].beginning_of_day)
		end

end
