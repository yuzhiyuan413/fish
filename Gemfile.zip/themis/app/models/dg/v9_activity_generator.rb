# -*- encoding : utf-8 -*-
class Dg::V9ActivityGenerator < Dg::Generator

	def generate
		ActiveRecord::Base.transaction do
			activation_records.each do |record|
				r = Seed::ActivityReport.find_or_initialize_by_report_time_and_tag(
					params[:date], record.tag)
				r.v9_activation_num = record.activation_num
				r.save
			end
		end

		ActiveRecord::Base.transaction do
			activity_records.each do |record|
				r = Seed::ActivityReport.find_or_initialize_by_report_time_and_tag(
					params[:date], record.tag)
				r.v9_activity_num = record.activity_num
				r.v9_request_num = record.request_times
				r.save
			end
		end

		summary_tags = System::TagGroup.distribute_sum_tags(Seed::ActivityReport.tags)
		ActiveRecord::Base.transaction do
			summary_tags.each do |tags|
				tag_lbl = tags.is_a?(Array) ? tags.shift : tags
				r = Seed::ActivityReport.find_or_initialize_by_report_time_and_tag(
					params[:date], tag_lbl)
				r.v9_activation_num = count_activation(tags)
				r.v9_activity_num = count_activity(tags)
				r.v9_request_num = count_request(tags)
				r.save
			end
		end

		System::TagGroup.reset_tags_options_cache(Seed::ActivityReport, System::Constant::PICK_OPTIONS[Seed::ActivityReport])
	end

	private
	def activation_records
		getr(:charge_activation).activation_records_v9(params[:date].beginning_of_day, params[:date].end_of_day, [:tag])
	end

	def activity_records
		getr(:charge_activity).activity_records_v9(params[:date].beginning_of_day,params[:date].end_of_day, ["charge_users.tag"])
	end

	def count_activation tag
		getr(:charge_activation).count_activation_v9(tag, params[:date].beginning_of_day)
	end

	def count_activity tag
		getr(:charge_activity).count_activity_v9(tag, params[:date].beginning_of_day)
	end

	def count_request tag
		getr(:charge_activity).count_request_v9(tag, params[:date].beginning_of_day)
	end

end
