# -*- encoding : utf-8 -*-
class Dg::ChargeActivityMonthGenerator < Dg::Generator

  include Dg::GeneratorHelper
  include ChargeHelper

  def generate
    ActiveRecord::Base.transaction do
      where_clause = ["year(request_time) = ? and month(request_time) = ?", params[:date].year, params[:date].month]
      group_columns = [:province_id, :tag, :loader_version_short]
      select_columns = ["count(id) id","count(distinct uuid) uuid"]
      (0..group_columns.count).collect{|i| group_columns.combination(i).to_a }.flatten(1).each do |group_clause|
        select_clause = select_columns + group_clause
        records = ChargeDs::ChargeRequestHistory.select(select_clause).where(where_clause).group(group_clause)
        records_count = 0
        records.each do |record|
          find_conditions = charge_report_conditions group_columns, record
          find_conditions[:report_date] = params[:date].strftime("%Y/%m")
          r = Charge::ActivityMonthReport.find_or_initialize_by_report_date_and_tag_and_product_version_and_province(
            find_conditions)
          r.request_times = record.id
          r.activity_num = record.uuid
          r.request_per_avg = ratio(record.id, record.uuid)
          r.save
          records_count += 1
        end
      end
    end
    reset_charge_options_cache(Charge::ActivityMonthReport)
  end

end
