# -*- encoding : utf-8 -*-
class Dg::ApkMd5AlarmsRecordGenerator < Dg::Generator
	def generate

		begin_time = params[:date].beginning_of_day.strftime("%F %T")
		end_time = params[:date].end_of_day.strftime("%F %T")

		sql = <<-EOF
			insert into seed_apk_md5_alarms
			select a.id,a.uid,c.activating_tag,a.samd,a.record_time,a.created_at,a.updated_at
			from seed_request_histories a inner join users c on a.uid = c.current_uuid
			left join package_infos b on a.samd = b.md5
			where a.record_time between '#{begin_time}' and '#{end_time}'
			and b.md5 is null;
		EOF

		result = ActiveRecord::Base.establish_connection("dwh_smart_#{Rails.env}").connection.execute sql
	end

end
