# -*- encoding : utf-8 -*-
class Dg::ChargeAliveGenerator < Dg::Generator

  include Dg::GeneratorHelper
  include ChargeHelper

  def generate
    ActiveRecord::Base.transaction do
      find_columns = [:tag, :loader_version_short]
      alive_dates = date_range(params[:date], :ago)

      combinations(["charge_users.tag", "charge_users.loader_version_short"]).each do |group_columns|
        alive_dates.each do |alive_day, activation_date|
          records = stay_alive_records(activation_date, group_columns)
          records.each do |record|
            find_conditions = charge_report_conditions(find_columns, record)
            find_conditions[:report_date] = activation_date
            r = Charge::AliveReport.find_or_initialize_by_report_date_and_tag_and_product_version(
              find_conditions)
            r.send("stay_alive#{alive_day}_num=", record.stay_alive_num)
            r.save
          end
        end
      end

      combinations(["charge_users.tag", "charge_users.loader_version_short"]).each do |group_columns|
        activation_records(group_columns).each do |record|
          find_conditions = charge_report_conditions(find_columns, record)
          find_conditions[:report_date] = params[:date]
          r = Charge::AliveReport.find_or_initialize_by_report_date_and_tag_and_product_version(
            find_conditions)
          r.activation_num = record.activation_num
          r.save
        end
      end
    end
    reset_charge_options_cache(Charge::AliveReport)

  end

  private
    def stay_alive_records activation_date, group_columns
      getr(:charge_alive).stay_alive_records(activation_date, params[:date], group_columns)
    end

    def activation_records group_columns
      getr(:charge_activation).activation_records(params[:date].beginning_of_day,
        params[:date].end_of_day, group_columns)
    end
end
