# -*- encoding : utf-8 -*-
class Dg::SeedPropGenerator < Dg::Generator
  include Dg::GeneratorHelper

  OTHERS_BRAND_NAME = '其他厂商'
  SUMMARY_BRAND_NAME = '厂商汇总'
  TOP_BRAND_LIMIT = 20

  attr_accessor :top_brands

  def initialize
    @top_brands = {}
  end

  def generate
    clean_overdue_data

    ActiveRecord::Base.transaction do
      save_prop_count_reports(prop_records.group_by(&:tag))
    end

    grouped_count_records = {}
    summary_tags = System::TagGroup.distribute_sum_tags(Seed::PropReport.tags)
    summary_tags.each do |tag|
      tag_name = tag.is_a?(Array) ? tag.shift : tag
      grouped_count_records[tag_name] = prop_records_by_tag_group(tag)
    end
    ActiveRecord::Base.transaction do
      save_prop_count_reports(grouped_count_records)
    end

    ActiveRecord::Base.transaction do
      prop_sum_records.each do |record|
        r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
          params[:date], record.tag, SUMMARY_BRAND_NAME)
        r.count = record.did_count
        r.save
      end
    end
    summary_tags = System::TagGroup.distribute_sum_tags(Seed::PropReport.tags)
    ActiveRecord::Base.transaction do
      summary_tags.each do |tag|
        tag_name = tag.is_a?(Array) ? tag.shift : tag
        r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
          params[:date], tag_name, SUMMARY_BRAND_NAME)
        r.count = count_prop_sum_by_tag_group(tag)
        r.save
      end
    end

    ActiveRecord::Base.transaction do
      save_prop_succ_count_reports(prop_succ_records.group_by(&:tag))
    end

    grouped_succ_count_records = {}
    summary_tags = System::TagGroup.distribute_sum_tags(Seed::PropReport.tags)
    summary_tags.each do |tag|
      tag_name = tag.is_a?(Array) ? tag.shift : tag
      grouped_succ_count_records[tag_name] = prop_succ_records_by_tag_group(tag)
    end
    ActiveRecord::Base.transaction do
      save_prop_succ_count_reports(grouped_succ_count_records)
    end

    ActiveRecord::Base.transaction do
      prop_succ_sum_records.each do |record|
        r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
          params[:date], record.tag, SUMMARY_BRAND_NAME)
        r.success_count = record.did_count
        r.save
      end
    end

    summary_tags = System::TagGroup.distribute_sum_tags(Seed::PropReport.tags)
    ActiveRecord::Base.transaction do
      summary_tags.each do |tag|
        tag_name = tag.is_a?(Array) ? tag.shift : tag
        r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
          params[:date], tag_name, SUMMARY_BRAND_NAME)
        r.success_count = count_prop_succ_sum_by_tag_group(tag)
        r.save
      end
    end

    succ_proportion_ratio_sql = <<-EOF
      update seed_prop_reports a,
      (select tag, count, success_count from seed_prop_reports
      where report_date = '#{params[:date].to_s}' and manufacturer = '#{SUMMARY_BRAND_NAME}') b
      set a.succ_proportion_ratio = (a.success_count/b.success_count),
      a.proportion_ratio = (a.count/b.count)
      where a.report_date = '#{params[:date].to_s}' and a.tag = b.tag
    EOF
    success_ratio_sql = <<-EOF
      update seed_prop_reports
      set success_ratio = (success_count/count)
      where report_date = '#{params[:date].to_s}'
    EOF
    conn = ActiveRecord::Base.establish_connection(Rails.env).connection
    conn.execute succ_proportion_ratio_sql
    conn.execute success_ratio_sql

    System::TagGroup.reset_tags_options_cache(Seed::PropReport, System::Constant::PICK_OPTIONS[Seed::PropReport])
  end

  private
    def clean_overdue_data
      Seed::PropReport.destroy_all(:report_date => params[:date])
    end

    def save_prop_count_reports grouped_count_records
      grouped_count_records.each do |tag, records|
        sorted_records = records.sort_by(&:did_count)
        top_records = sorted_records.pop(TOP_BRAND_LIMIT)
        top_brands[tag] = top_records.map(&:ro_pd_brand)
        others_sum_count = sorted_records.blank? ? 0  : sorted_records.map(&:did_count).compact.sum
        top_records.each do |record|
          r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
            params[:date], tag, record.ro_pd_brand)
          r.count = record.did_count
          r.save
        end
        r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
          params[:date], tag, OTHERS_BRAND_NAME)
        r.count = others_sum_count
        r.save
      end
    end

    def save_prop_succ_count_reports grouped_succ_count_records
      grouped_succ_count_records.each do |tag, records|
        top_records = []
        other_records = []
        records.each do |r|
          if top_brands[tag].include? r.ro_pd_brand
            top_records << r
          else
            other_records << r
          end
        end
        others_sum_count = other_records.blank? ? 0  : other_records.map(&:did_count).compact.sum
        top_records.each do |record|
          r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
            params[:date], tag, record.ro_pd_brand)
          r.success_count = record.did_count
          r.save
        end
        r = Seed::PropReport.find_or_initialize_by_report_date_and_tag_and_manufacturer(
          params[:date], tag, OTHERS_BRAND_NAME)
        r.success_count = others_sum_count
        r.save
      end
    end

    def prop_records_by_tag_group(tag)
      getr(:sword_prop).prop_records_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def prop_records
      getr(:sword_prop).prop_records(params[:date].beginning_of_day)
    end

    def count_prop_sum_by_tag_group(tag)
      getr(:sword_prop).count_prop_sum_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def prop_sum_records
      getr(:sword_prop).prop_sum_records(params[:date].beginning_of_day)
    end


    def prop_succ_records
      getr(:sword_prop).prop_succ_records(params[:date].beginning_of_day)
    end

    def prop_succ_records_by_tag_group(tag)
      getr(:sword_prop).prop_succ_records_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def count_prop_succ_sum_by_tag_group(tag)
      getr(:sword_prop).count_prop_succ_sum_by_tag_group(tag, params[:date].beginning_of_day)
    end

    def prop_succ_sum_records
      getr(:sword_prop).prop_succ_sum_records(params[:date].beginning_of_day)
    end

end
