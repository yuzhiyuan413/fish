# -*- encoding : utf-8 -*-
class Dg::SeedSolutionGenerator < Dg::Generator

  include Dg::GeneratorHelper

  def generate

    records = event_sum_records("active")
    ActiveRecord::Base.transaction do
      records.each do |record|
        r = Seed::SolutionReport.find_or_initialize_by_report_date_and_tag_and_plan_id(
        params[:date], record.tag, 0)
        r.send("active_count=", record.did_count)
        r.save
      end
    end

    summary_tags = System::TagGroup.distribute_sum_tags(Seed::SolutionReport.tags)
    ActiveRecord::Base.transaction do
      summary_tags.each do |tags|
        tag_lbl = tags.is_a?(Array) ? tags.shift : tags
        count = count_event_sum_by_tag_group(tags, "active")
        r = Seed::SolutionReport.find_or_initialize_by_report_date_and_tag_and_plan_id(
        params[:date], tag_lbl, 0)
        r.send("active_count=", count)
        r.save
      end
    end

    ModelMappings::EVENT_TO_EVENT_ID.each do |event_name, event_id|
      records = event_records(event_id, ModelMappings::EVENT_TO_CONDITIONS[event_name])
      ActiveRecord::Base.transaction do
        records.each do |record|
          r = Seed::SolutionReport.find_or_initialize_by_report_date_and_tag_and_plan_id(
            params[:date], record.tag, record.solution_id)
          r.send(ModelMappings::EVENT_TO_SETTER_FUNC[event_name], record.did_count)
          r.save
        end
      end
    end

    ModelMappings::EVENT_TO_EVENT_ID.each do |event_name, event_id|
      records = event_sum_records(event_id, ModelMappings::EVENT_TO_CONDITIONS[event_name])
      ActiveRecord::Base.transaction do
        records.each do |record|
          r = Seed::SolutionReport.find_or_initialize_by_report_date_and_tag_and_plan_id(
            params[:date], record.tag, 0)
          r.send(ModelMappings::EVENT_TO_SETTER_FUNC[event_name], record.did_count)
          r.save
        end
      end
    end

    summary_tags = System::TagGroup.distribute_sum_tags(Seed::SolutionReport.tags)
    ActiveRecord::Base.transaction do
      summary_tags.each do |tags|
        tag_lbl = tags.is_a?(Array) ? tags.shift : tags
        ModelMappings::EVENT_TO_EVENT_ID.each do |event_name, event_id|
          records = event_records_by_tag_group(tags, event_id, ModelMappings::EVENT_TO_CONDITIONS[event_name])
          records.each do |record|
            r = Seed::SolutionReport.find_or_initialize_by_report_date_and_tag_and_plan_id(
              params[:date], tag_lbl, record.solution_id)
            r.send(ModelMappings::EVENT_TO_SETTER_FUNC[event_name], record.did_count)
            r.save
          end
        end
      end
    end

    summary_tags = System::TagGroup.distribute_sum_tags(Seed::SolutionReport.tags)
    ActiveRecord::Base.transaction do
      summary_tags.each do |tags|
        tag_lbl = tags.is_a?(Array) ? tags.shift : tags
        ModelMappings::EVENT_TO_EVENT_ID.each do |event_name, event_id|
          count = count_event_sum_by_tag_group(tags, event_id, ModelMappings::EVENT_TO_CONDITIONS[event_name])
          r = Seed::SolutionReport.find_or_initialize_by_report_date_and_tag_and_plan_id(
            params[:date], tag_lbl, 0)
          r.send(ModelMappings::EVENT_TO_SETTER_FUNC[event_name], count)
          r.save
        end
      end
    end

    succ_proportion_ratio_sql = <<-EOF
      update seed_solution_reports a,
      (select tag,success_count from seed_solution_reports
      where report_date = '#{params[:date].to_s}' and plan_id = 0 ) b
      set a.succ_proportion_ratio = (a.success_count/b.success_count)
      where a.report_date = '#{params[:date].to_s}' and a.tag = b.tag
    EOF
    return_ratio_success_ratio_sql = <<-EOF
      update seed_solution_reports
      set success_ratio = success_count/execting_count,
      return_ratio = exected_count/execting_count,
      installed_ratio = installed_count/success_count,
      v8_exists_ratio = v8_exists_count/success_count,
      v9_exists_ratio = v9_exists_count/success_count
      where report_date = '#{params[:date].to_s}'
    EOF
    conn = ActiveRecord::Base.establish_connection(Rails.env).connection
    conn.execute succ_proportion_ratio_sql
    conn.execute return_ratio_success_ratio_sql

    System::TagGroup.reset_tags_options_cache(Seed::SolutionReport, System::Constant::PICK_OPTIONS[Seed::SolutionReport])
  end

  private
    def event_sum_records(solution_event_id, status_flag=nil)
      getr(:sword_solution_event).event_sum_records(solution_event_id, params[:date].beginning_of_day, params[:date].end_of_day, status_flag)
    end

    def event_records_by_tag_group(tag, solution_event_id, status_flag=nil)
      getr(:sword_solution_event).event_records_by_tag_group(tag, solution_event_id, params[:date].beginning_of_day, params[:date].end_of_day, status_flag)
    end

    def event_records(solution_event_id, status_flag=nil)
      getr(:sword_solution_event).event_records(solution_event_id, params[:date].beginning_of_day, params[:date].end_of_day, status_flag)
    end

    def count_event_sum_by_tag_group(tag, solution_event_id, status_flag=nil)
      getr(:sword_solution_event).count_event_sum_by_tag_group(tag, solution_event_id, params[:date].beginning_of_day, params[:date].end_of_day, status_flag)
    end


end
