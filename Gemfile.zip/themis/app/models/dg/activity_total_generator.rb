# -*- encoding : utf-8 -*-
class Dg::ActivityTotalGenerator < Dg::Generator

	def generate
		clean_overdue_data

		star = seed_total_activation_records
		sary = seed_activation_records(Date.yesterday)
		sanr = seed_activity_num_records(Date.yesterday.beginning_of_day, Date.yesterday.end_of_day)
		sanr7 = seed_activity_num_records(7.days.ago.beginning_of_day, Time.now)
		sanr30 = seed_activity_num_records(30.days.ago.beginning_of_day, Time.now)

		ActiveRecord::Base.transaction do
			star.each do |record|
				r = Seed::ActivityTotalReport.find_or_initialize_by_report_type_and_tag(Seed::ActivityReport.to_s, record.activating_tag)
				r.total_activation_num = record.uid
				r.yesterday_activation_num = sary.select{|x| x.activating_tag.eql?(record.activating_tag) }.first.try(:uid).to_i
				r.yesterday_activity_num = sanr.select{|x| x.tag.eql?(record.activating_tag) }.first.try(:uid).to_i
				r.activity7 = sanr7.select{|x| x.tag.eql?(record.activating_tag) }.first.try(:uid).to_i
				r.activity30 = sanr30.select{|x| x.tag.eql?(record.activating_tag) }.first.try(:uid).to_i
				r.save
			end
		end

		summary_tags = System::TagGroup.distribute_sum_tags(Seed::ActivityTotalReport.tags)
		ActiveRecord::Base.transaction do
	    summary_tags.each do |tags|
					tag_lbl = tags.is_a?(Array) ? tags.shift : tags
					r = Seed::ActivityTotalReport.find_or_initialize_by_report_type_and_tag(Seed::ActivityReport.to_s, tag_lbl)
					r.total_activation_num = total_activation_num(tags)
					r.yesterday_activation_num = count_seed_activation(tags, Date.yesterday.beginning_of_day,Date.yesterday.end_of_day)
					r.yesterday_activity_num = count_seed_activity(tags, Date.yesterday.beginning_of_day,Date.yesterday.end_of_day)
					r.activity7 = count_seed_activity(tags, 7.days.ago.beginning_of_day, Time.now)
					r.activity30 = count_seed_activity(tags, 30.days.ago.beginning_of_day, Time.now)
					r.save
			end
		end

	end

	private
	def clean_overdue_data
		Seed::ActivityTotalReport.destroy_all("updated_at < #{params[:date].yesterday.to_s}")
	end

	def seed_total_activation_records
		getr(:seed).total_activation_records
	end

	def seed_activation_records report_date
		getr(:seed).activation_records(report_date.beginning_of_day, report_date.end_of_day)
	end

	def seed_activity_num_records begin_time, end_time
		getr(:request_history).activity_num_records(begin_time, end_time)
	end

	def count_seed_activity(tag, begin_time, end_time)
		getr(:request_history).count_activity(tag, begin_time, end_time)
	end

	def count_seed_activation(tag, begin_time, end_time)
		getr(:seed).count_activation(tag, begin_time, end_time)
	end

	def total_activation_num tag
		getr(:activity).total_activation_num(Seed::ActivityReport.to_s,tag)
  end

end
