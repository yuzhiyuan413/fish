# -*- encoding : utf-8 -*-
class Reactor 

	attr_accessor :params, :repositories, :generators

	def initialize params=nil
    load_generators_repositories
		@params = params
		@repositories = init_repositories
	end

	def run generator_type
		get_generator(generator_type.to_s).generate
	end

	private
	def init_repositories
		repositories = Ds::Repository.subclasses.collect do |cls|
      c = cls.new
      c.params = params
      c
    end
    repositories.each { |r| r.repositories = repositories }
    repositories
	end

	def init_generators
		generators = Dg::Generator.subclasses.collect do |cls|
      c = cls.new
      c.params = params
      c.repositories = self.repositories
      c
    end
    generators
	end

	def get_generator(rid)
    generator = "Dg::#{rid.camelcase}Generator".constantize.new
    raise "没有支持的Generator. #{rid}" if generator.blank?
    
    generator.tap do |x|
      x.params = params
      x.repositories = repositories
    end  
  end

	def load_generators_repositories
		generators = Dir.glob(File.expand_path("../dg/*",__FILE__))
		generators.each{|generator| load generator }
    repositories = Dir.glob(File.expand_path("../ds/*",__FILE__))
		repositories.each{|repositorie| load repositorie }
	end

end
