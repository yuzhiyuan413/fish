# -*- encoding : utf-8 -*-
class Median < ActiveRecord::Base
  attr_accessible :median_ratio15, :median_ratio2, :median_ratio3, :median_ratio30, :median_ratio7, :name
end
