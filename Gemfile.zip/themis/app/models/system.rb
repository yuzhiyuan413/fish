# -*- encoding : utf-8 -*-
module System
  def self.table_name_prefix
    'system_'
  end
end
