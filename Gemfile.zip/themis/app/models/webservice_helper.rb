# -*- encoding : utf-8 -*-
class WebserviceError < RuntimeError
end

module WebserviceHelper

	def self.included(base)
    base.send :include, InstanceMethods
    base.extend ClassMethods
  end

  module InstanceMethods
		def webservice response, name
	  	data = response.to_hash
	  	response_key = "#{name}_response".to_sym
	  	raise "返回数据异常" if data[response_key].nil? or data[response_key][:return].nil?
	  	data = data[response_key][:return]
	  	raise WebserviceError, data[:desc] if data[:code].to_i == -1
	  	return data[:result]
		end

		def province_webservice response, name
			data = response.to_hash
			response_key = "#{name}_response".to_sym
			raise "返回数据异常" if data[response_key].nil? or data[response_key][:return].nil?
			data = data[response_key][:return]
			data
		end
	end

	module ClassMethods
		def load_config(name)
	    config = YAML.load_file("config/webservice.yml")
	    env = config[Rails.env]
	    return "http://#{env["host"]}:#{env["port"]}/#{env["uri"]}/#{name.camelize}WebService?wsdl"
  	end

  	def log_switch
  		Rails.env.development? ? true : false
  	end
	end
end
