class Box
  Body = "box_body"
  Footer = "box_footer"
end
