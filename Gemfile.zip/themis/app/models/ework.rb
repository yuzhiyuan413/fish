# -*- encoding : utf-8 -*-
module Ework
  def self.table_name_prefix
    'ework_'
  end
end
