# Load the Rails application.
require File.expand_path('../application', __FILE__)
require File.expand_path('../../lib/log_file', __FILE__)
# Initialize the Rails application.
Rails.application.initialize!
