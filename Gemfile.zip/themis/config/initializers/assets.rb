# Be sure to restart your server when you modify this file.

# Version of your assets, change this if you want to expire all your assets.
Rails.application.config.assets.version = '1.0'

# Add additional assets to the asset load path
# Rails.application.config.assets.paths << Emoji.images_path

# Precompile additional assets.
# application.js, application.css, and all non-JS/CSS in app/assets folder are already added.
Rails.application.config.assets.precompile += %w(*.png *.jpg *.jpeg *.gif login.css adminlte.js)
Rails.application.config.assets.precompile += %w( bootstrap_custom.css )
Rails.application.config.assets.precompile += %w( bootstrap.js )
Rails.application.config.assets.precompile += %w( bootstrap-combobox.css )
Rails.application.config.assets.precompile += %w( bootstrap-combobox.js )
Rails.application.config.assets.precompile += %w( jquery_pin.js )
Rails.application.config.assets.precompile += %w( bootstrap-sortable.css )
Rails.application.config.assets.precompile += %w( bootstrap-sortable.js )
Rails.application.config.assets.precompile += %w( bootstrap-table.css )
Rails.application.config.assets.precompile += %w( bootstrap-table.js )
Rails.application.config.assets.precompile += %w( bootstrap-table-export.js )
Rails.application.config.assets.precompile += %w( tableExport.js )
Rails.application.config.assets.precompile += %w( jquery-base64.js )
Rails.application.config.assets.precompile += %w( bootstrap-table-zh-CN.js )
Rails.application.config.assets.precompile += %w( ladda-themeless.css )
Rails.application.config.assets.precompile += %w( spin.js )
Rails.application.config.assets.precompile += %w( ladda.js )

# Rails.application.config.assets.precompile += %w( app.min.js )
# Rails.application.config.assets.precompile += %w( jquery.dataTables.min.js )
# Rails.application.config.assets.precompile += %w( dataTables.fixedColumns.min.js )
# Rails.application.config.assets.precompile += %w( dataTables.buttons.min.js )
# Rails.application.config.assets.precompile += %w( buttons.flash.min.js )
# Rails.application.config.assets.precompile += %w( jszip.min.js )
# Rails.application.config.assets.precompile += %w( pdfmake.min.js )
# Rails.application.config.assets.precompile += %w( vfs_fonts.js )
# Rails.application.config.assets.precompile += %w( buttons.html5.min.js )
# Rails.application.config.assets.precompile += %w( buttons.print.min.js )
# Rails.application.config.assets.precompile += %w( ladda.js )