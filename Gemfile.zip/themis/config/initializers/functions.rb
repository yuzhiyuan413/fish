
Rails.cache.delete_matched("sidebar_*")

Pass::System.define_subsystem "系统管理" do |s|
  s.attributes id: 0, controller: "system/accounts", action: "left", hidden: 0, icon_class: "fa fa-dashboard"

  s.define_function "帐号管理" do |f|
    f.attributes id: 1, controller: "system/accounts", action: "index", hidden: 0, url: "", icon_class: "fa fa-circle-o"
    f.define_controller name: "system/accounts", description: "帐号管理", function_id: 1
    f.define_controller name: "system/functions", description: "帐号功能模块", function_id: 1
    f.define_controller name: "system/permissions", description: "帐号权限设置", function_id: 1
    f.define_controller name: "system/rate_manages", description: "比例设置", function_id: 1
  end

  s.define_function "角色管理" do |f|
    f.attributes id: 2, controller: "system/roles", action: "index", hidden: 0, url: "", icon_class: "fa fa-circle-o"
    f.define_controller name: "system/roles", description: "角色管理", function_id: 2
  end

  s.define_function "发布日志" do |f|
    f.attributes id: 3, controller: "system/changes", action: "index", hidden: 1, url: "", icon_class: "fa fa-circle-o"
    f.define_controller name: "system/changes", description: "发布日志", function_id: 3
  end

  s.define_function "查看日志" do |f|
    f.attributes id: 4, controller: "system/logs", action: "index", hidden: 0, url: "", icon_class: "fa fa-circle-o"
    f.define_controller name: "system/logs", description: "查看日志", function_id: 4
  end

  s.define_function "修改密码" do |f|
    f.attributes id: 6, controller: "system/update_password", action: "edit_password", hidden: 1, url: "", icon_class: "fa fa-circle-o"
    f.define_controller name: "system/update_password", description: "修改密码", function_id: 6
  end

  s.define_function "退出系统" do |f|
    f.attributes id: 7, controller: "system/login", action: "logout", hidden: 1, url: "", icon_class: "fa fa-circle-o"
    f.define_controller name: "system/login", description: "退出系统", function_id: 7
  end

end

Pass::System.define_subsystem "种子报表" do |s|
  s.attributes :id => 10, :controller => "seed_activation_reports", :action => "left", :sort => "1", :hidden => 0

  s.define_function "用户概况" do |f|
    f.attributes :id => 11, :controller => "seed/activity_situation_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/activity_situation_reports", :description => "用户概况", :function_id => 11
  end

  s.define_function "活跃用户" do |f|
    f.attributes :id => 12, :controller => "seed/activity_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/activity_reports", :description => "活跃用户", :function_id => 12
  end

  s.define_function "新增用户" do |f|
    f.attributes :id => 13, :controller => "seed/activation_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/activation_reports", :description => "新增用户", :function_id => 13
  end

  s.define_function "留存用户" do |f|
    f.attributes :id => 14, :controller => "seed/alive_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/alive_reports", :description => "留存用户", :function_id => 14
  end

  s.define_function "方案执行" do |f|
    f.attributes :id => 15, :controller => "seed/solution_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/solution_reports", :description => "方案执行", :function_id => 15
  end

  s.define_function "终端厂商" do |f|
    f.attributes :id => 16, :controller => "seed/prop_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/prop_reports", :description => "终端厂商", :function_id => 16
  end

  s.define_function "终端属性" do |f|
    f.attributes :id => 17, :controller => "seed/prop_detail_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/prop_detail_reports", :description => "终端属性", :function_id => 17
  end

  s.define_function "系统参数-终端属性" do |f|
    f.attributes :id => 20, :controller => "seed/device_detail_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/device_detail_reports", :description => "系统参数-终端属性", :function_id => 20
  end

  s.define_function "终端属性月汇总" do |f|
    f.attributes :id => 18, :controller => "seed/prop_detail_monthly_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/prop_detail_monthly_reports", :description => "终端属性月汇总", :function_id => 18
  end

  s.define_function "种子全事件到达" do |f|
    f.attributes :id => 19, :controller => "seed/arrival_reports", :action => "index", :sort => "10", :hidden => 0, :url => ""
    f.define_controller :name => "seed/arrival_reports", :description => "基于种子AID激活用户的全事件到达情况", :function_id => 19
  end


end