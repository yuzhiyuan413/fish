LOG_DIR = YAML::load_file(File.join(Rails.root,"config","log_dir.yml"))
